"""Small illustrated food pictures (inline SVG, top-down) for meal cards. Offline, consistent style, never broken links."""
import re
from markupsafe import Markup

BG = {"veg_bowl": "#e6f5ec", "dal": "#fdf0d2", "porridge": "#fdeee6", "toast": "#fbeedd", "salad": "#e8f6e7", "fruit": "#fde9e3",
      "nuts": "#f6ecdd", "soup": "#fde9de", "broth": "#fdf3d8", "curry_roti": "#fdeedd", "egg": "#fff4d6", "protein_plate": "#e6f1f7",
      "tea": "#e8f5ef", "yoghurt": "#f1ebfb", "idli": "#edf4fb", "wrap": "#f9efe0", "snack_plate": "#e9f6ea", "sweet_potato": "#fdeee3",
      "khichdi": "#fff3d6"}


def _dots(color, pts, r=2.2, extra=""):
    return "".join(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{color}" {extra}/>' for x, y in pts)


def _bowl(k, inner, cx=50, cy=51, R=36, rim="#fffaf3"):
    ir = R - 8.5
    return (f'<ellipse cx="{cx}" cy="{cy+6}" rx="{R+1}" ry="{R-1}" fill="#6b4a2a" opacity=".13"/>'
            f'<circle cx="{cx}" cy="{cy}" r="{R}" fill="{rim}"/><circle cx="{cx}" cy="{cy}" r="{R}" fill="none" stroke="#e6dcc9" stroke-width="1.2"/>'
            f'<circle cx="{cx}" cy="{cy}" r="{ir+1.6}" fill="#000" opacity=".08"/>'
            f'<clipPath id="cp-{k}-{R}"><circle cx="{cx}" cy="{cy}" r="{ir}"/></clipPath><g clip-path="url(#cp-{k}-{R})">{inner}</g>'
            f'<path d="M{cx-R+5} {cy-8} A{R-3} {R-3} 0 0 1 {cx-10} {cy-R+4}" stroke="#fff" stroke-width="2.6" stroke-linecap="round" fill="none" opacity=".75"/>')


def _plate(cx=50, cy=51, R=37):
    return (f'<ellipse cx="{cx}" cy="{cy+6}" rx="{R}" ry="{R-2}" fill="#6b4a2a" opacity=".13"/><circle cx="{cx}" cy="{cy}" r="{R}" fill="#fffdf8"/>'
            f'<circle cx="{cx}" cy="{cy}" r="{R}" fill="none" stroke="#e6dcc9" stroke-width="1.2"/><circle cx="{cx}" cy="{cy}" r="{R-7}" fill="none" stroke="#efe6d6" stroke-width="1"/>')


def _leaf(x, y, rot=0, c="#5aa84f", s=1.0):
    return f'<ellipse cx="{x}" cy="{y}" rx="{5*s}" ry="{2.6*s}" fill="{c}" transform="rotate({rot} {x} {y})"/>'


def veg_bowl():
    inner = ('<rect width="100" height="100" fill="#f3e6bd"/>'
             + _dots("#e9d49a", [(34, 62), (62, 66), (48, 70), (70, 56), (30, 50)], 3)
             + '<circle cx="39" cy="42" r="6.5" fill="#4f9b4b"/><circle cx="46" cy="38" r="5.5" fill="#5fae58"/><circle cx="35" cy="48" r="5" fill="#468f43"/>'
             + _dots("#7cc36a", [(37, 40), (44, 36), (33, 47)], 1.8)
             + ''.join(f'<circle cx="{x}" cy="{y}" r="4.6" fill="#f08a2a"/><circle cx="{x}" cy="{y}" r="1.7" fill="#f8b866"/>' for x, y in [(61, 41), (67, 49), (58, 51)])
             + ''.join(f'<circle cx="{x}" cy="{y}" r="5.4" fill="#e4483f"/><circle cx="{x-1.5}" cy="{y-1.5}" r="1.5" fill="#f58a80"/>' for x, y in [(45, 62), (56, 64)])
             + _dots("#f2c230", [(52, 48), (48, 52), (54, 54), (42, 54), (66, 62)], 1.7)
             + _leaf(33, 60, -30, "#7cc36a") + _leaf(70, 36, 40, "#6fbf5f") + _leaf(52, 74, 10, "#6fbf5f"))
    return _bowl("veg", inner)


def dal():
    roti = ('<circle cx="76" cy="77" r="19" fill="#ecd09c" stroke="#d6b377" stroke-width="1.2"/>' + _dots("#c79852", [(70, 72), (80, 70), (74, 82), (84, 80), (68, 80)], 1.8))
    inner = ('<rect width="100" height="100" fill="#eab02c"/><path d="M30 46 Q50 36 70 48" stroke="#f7d57f" stroke-width="3" fill="none" stroke-linecap="round"/><path d="M34 60 Q50 52 66 62" stroke="#d9951a" stroke-width="2.5" fill="none" stroke-linecap="round"/>'
             + _dots("#4f9b4b", [(44, 50), (52, 46), (58, 54), (48, 58)], 1.9) + '<path d="M54 40 q6 -4 8 2" stroke="#d63a2e" stroke-width="2.2" fill="none" stroke-linecap="round"/>')
    return roti + _bowl("dal", inner, 42, 42, 31)


def porridge():
    inner = ('<rect width="100" height="100" fill="#ead9bd"/>' + _dots("#d9c59f", [(36, 44), (58, 40), (62, 60), (40, 64)], 3.2)
             + ''.join(f'<circle cx="{x}" cy="{y}" r="3.6" fill="{c}"/>' for x, y, c in [(40, 42, "#7a3b8f"), (47, 38, "#c43d5a"), (36, 50, "#c43d5a"), (60, 62, "#7a3b8f"), (54, 66, "#c43d5a")])
             + ''.join(f'<circle cx="{x}" cy="{y}" r="5" fill="#fbe9a8" stroke="#e0c775" stroke-width="1"/><circle cx="{x}" cy="{y}" r="1.2" fill="#c9a24a"/>' for x, y in [(58, 44), (65, 50), (50, 55)])
             + ''.join(f'<ellipse cx="{x}" cy="{y}" rx="3.4" ry="2" fill="#b57c3e" transform="rotate({r} {x} {y})"/>' for x, y, r in [(44, 60, 30), (68, 40, -20), (38, 56, 70)])
             + _leaf(52, 46, 30, "#5fae58", .8))
    return _bowl("por", inner)


def toast():
    def slice_(tx, ty, rot, topping):
        return (f'<g transform="rotate({rot} {tx+17} {ty+17})"><path d="M{tx} {ty+8} q0 -10 9 -10 h16 q9 0 9 10 q0 6 -3 7 v16 q0 5 -5 5 h-22 q-5 0 -5 -5 v-16 q-3 -1 -3 -7z" fill="#ecc78a" stroke="#c98f4a" stroke-width="1.6"/>'
                f'<path d="M{tx+4} {ty+9} q0 -6 6 -6 h14 q6 0 6 6 v22 q0 2 -3 2 h-20 q-3 0 -3 -2z" fill="#f5deb0"/>{topping}</g>')
    avo = '<path d="M14 18 q8 -6 16 0 q6 8 -2 14 q-10 4 -16 -2 q-3 -7 2 -12z" fill="#8cc152"/><path d="M17 20 q6 -3 10 0 q3 5 -1 9 q-6 2 -9 -2z" fill="#aad56c"/><circle cx="22" cy="26" r="2.4" fill="#b0824a"/>'
    tom = ''.join(f'<circle cx="{x}" cy="{y}" r="4.6" fill="#e4483f"/><circle cx="{x}" cy="{y}" r="2" fill="#f3877d"/>' for x, y in [(18, 20), (28, 25), (20, 31)])
    return slice_(12, 12, -10, avo + tom) .replace('transform="rotate(-10 29 29)"', 'transform="translate(2 4) rotate(-10 29 29)"') + slice_(46, 40, 12, '<path d="M50 46 q10 -4 20 0 q4 8 -2 12 q-10 4 -18 -1 q-3 -6 0 -11z" fill="#d8c08a"/>' + _dots("#b9524a", [(56, 52), (62, 49), (66, 54)], 2.2) + _dots("#4f9b4b", [(60, 56)], 1.6))


def salad():
    inner = ('<rect width="100" height="100" fill="#7bc46a"/>'
             + ''.join(f'<ellipse cx="{x}" cy="{y}" rx="9" ry="5" fill="{c}" transform="rotate({r} {x} {y})"/>' for x, y, c, r in [(38, 40, "#5aa84f", -30), (60, 38, "#8fd17a", 25), (48, 52, "#4f9b4b", 70), (36, 62, "#8fd17a", 20), (64, 60, "#5aa84f", -40), (50, 34, "#a2dd8a", 10)])
             + ''.join(f'<circle cx="{x}" cy="{y}" r="5.4" fill="#e4483f"/><circle cx="{x-1.6}" cy="{y-1.6}" r="1.6" fill="#f68a7f"/>' for x, y in [(44, 46), (58, 52), (40, 58)])
             + ''.join(f'<circle cx="{x}" cy="{y}" r="4.4" fill="#e1f3cc" stroke="#9fd07f" stroke-width="1.4"/><circle cx="{x}" cy="{y}" r="1.3" fill="#b9dd9a"/>' for x, y in [(54, 40), (66, 48), (46, 64)])
             + '<path d="M60 64 q6 -6 12 0 q-6 8 -12 0z" fill="#d9ec8a"/><path d="M34 46 q4 -3 8 0" stroke="#a45db3" stroke-width="2" fill="none" stroke-linecap="round"/>')
    return _bowl("sal", inner)


def fruit():
    return ('<ellipse cx="52" cy="84" rx="38" ry="6" fill="#6b4a2a" opacity=".12"/>'
            '<circle cx="35" cy="56" r="21" fill="#e04545"/><circle cx="35" cy="56" r="21" fill="url(#af)"/><path d="M35 36 q-1 -8 5 -12" stroke="#7a4a2a" stroke-width="2.4" fill="none" stroke-linecap="round"/><ellipse cx="44" cy="30" rx="7" ry="3.4" fill="#5fae58" transform="rotate(-25 44 30)"/><ellipse cx="26" cy="48" rx="4" ry="7" fill="#fff" opacity=".35" transform="rotate(20 26 48)"/>'
            '<circle cx="68" cy="52" r="18" fill="#f59a2b"/><circle cx="68" cy="52" r="14" fill="#fbb85a"/>' + ''.join(f'<path d="M68 52 L{68+14*__import__("math").cos(a):.1f} {52+14*__import__("math").sin(a):.1f}" stroke="#f59a2b" stroke-width="1.3"/>' for a in [i * 1.0472 for i in range(6)])
            + '<circle cx="68" cy="52" r="3" fill="#f59a2b"/><ellipse cx="76" cy="36" rx="6" ry="3" fill="#5fae58" transform="rotate(30 76 36)"/>'
            '<defs><radialGradient id="af" cx=".35" cy=".3"><stop offset="0" stop-color="#fff" stop-opacity=".25"/><stop offset="1" stop-color="#8a1b1b" stop-opacity=".25"/></radialGradient></defs>')


def nuts():
    inner = ('<rect width="100" height="100" fill="#f1e2c8"/>'
             + ''.join(f'<ellipse cx="{x}" cy="{y}" rx="6.5" ry="3.8" fill="#b97a3e" transform="rotate({r} {x} {y})"/><ellipse cx="{x-1}" cy="{y-1}" rx="3" ry="1.2" fill="#d9a066" transform="rotate({r} {x} {y})"/>' for x, y, r in [(40, 44, 30), (54, 40, -20), (60, 54, 60), (44, 58, 100), (52, 50, 10), (36, 54, -50)])
             + ''.join(f'<circle cx="{x}" cy="{y}" r="5.4" fill="#a8764a"/><path d="M{x-3} {y} q3 -4 6 0 M{x-3} {y+2} q3 -3 6 0" stroke="#7d5232" stroke-width="1" fill="none"/>' for x, y in [(48, 46), (58, 62)]))
    return _bowl("nut", inner, 46, 46, 31, "#f6e6c8") + ''.join(f'<ellipse cx="{x}" cy="{y}" rx="5" ry="3" fill="#b97a3e" transform="rotate({r} {x} {y})"/>' for x, y, r in [(78, 76, 30), (86, 66, -30), (70, 84, 80)])


def soup(color="#e8613c", broth=False):
    inner = (f'<rect width="100" height="100" fill="{color}"/>' + ('<path d="M30 46 Q50 40 70 48 M32 58 Q50 52 68 60" stroke="#fff" stroke-width="2" opacity=".25" fill="none"/>' if broth else '<path d="M32 46 Q44 38 52 48 T70 50" stroke="#fbe7cf" stroke-width="3.2" fill="none" stroke-linecap="round"/>')
             + (''.join(f'<circle cx="{x}" cy="{y}" r="3.2" fill="{c}"/>' for x, y, c in [(40, 52, "#f08a2a"), (56, 44, "#6bb35a"), (60, 58, "#f08a2a"), (46, 62, "#6bb35a"), (36, 42, "#f2c230"), (66, 48, "#6bb35a")]) if broth else _dots("#4f9b4b", [(48, 56), (56, 52), (42, 50)], 1.7)))
    spoon = '<ellipse cx="82" cy="78" rx="6" ry="9" fill="#d6d9de" transform="rotate(35 82 78)"/><path d="M78 70 L66 56" stroke="#c4c8ce" stroke-width="3.4" stroke-linecap="round"/>'
    return _bowl("soup" + ("b" if broth else ""), inner, 46, 46, 34) + spoon


def curry_roti():
    roti = '<circle cx="36" cy="60" r="25" fill="#ecd09c" stroke="#d6b377" stroke-width="1.2"/>' + _dots("#c79852", [(26, 52), (38, 48), (44, 62), (30, 68), (40, 74), (24, 62)], 2)
    inner = ('<rect width="100" height="100" fill="#d9622b"/><path d="M26 40 Q44 30 62 42" stroke="#f08a4a" stroke-width="3" fill="none"/>' + _dots("#ebc77b", [(40, 36), (50, 42), (44, 48), (56, 38), (36, 44)], 3.2) + _dots("#4f9b4b", [(46, 34), (54, 46)], 1.6))
    return roti + _bowl("cur", inner, 68, 36, 24, "#fffaf3")


def egg():
    return (_plate() + '<path d="M22 54 q4 -22 28 -22 q26 0 28 22 q-2 14 -28 14 q-26 0 -28 -14z" fill="#f6cf45"/><path d="M26 54 q4 -16 24 -16 q20 0 24 16" fill="#fbe27a"/><path d="M26 56 Q50 46 74 56" stroke="#e0b52c" stroke-width="2" fill="none"/>'
            + _dots("#4f9b4b", [(40, 46), (56, 44), (62, 52), (46, 54), (34, 54)], 1.8) + '<circle cx="68" cy="66" r="5" fill="#e4483f"/><circle cx="66.6" cy="64.6" r="1.4" fill="#f58a80"/>')


def protein_plate():
    return (_plate() + '<g transform="rotate(-18 46 46)"><ellipse cx="44" cy="46" rx="22" ry="11" fill="#f4a37a"/><ellipse cx="44" cy="44" rx="19" ry="8" fill="#f8b894"/>' + ''.join(f'<path d="M{x} 36 L{x+4} 54" stroke="#c9704a" stroke-width="2.2" stroke-linecap="round"/>' for x in (34, 42, 50, 58)) + '</g>'
            + ''.join(f'<path d="M{x} 66 q8 -4 16 -2" stroke="#5aa84f" stroke-width="3" stroke-linecap="round" fill="none"/>' for x in (22, 26, 30)) + '<circle cx="72" cy="62" r="10" fill="#f7f1e2"/>' + _dots("#e6dcc3", [(68, 60), (74, 58), (72, 66), (66, 66)], 1.6)
            + '<path d="M66 28 a10 10 0 0 1 14 14 z" fill="#f7e26b" stroke="#e5c92f" stroke-width="1.2"/>')


def tea():
    return ('<ellipse cx="50" cy="60" rx="37" ry="33" fill="#6b4a2a" opacity=".12"/><circle cx="50" cy="50" r="35" fill="#fffaf3" stroke="#e6dcc9" stroke-width="1.2"/><circle cx="46" cy="50" r="22" fill="#fff" stroke="#e1d8c6" stroke-width="1.4"/>'
            '<circle cx="46" cy="50" r="17" fill="#a9c77b"/><path d="M34 46 Q46 38 58 48" stroke="#fff" stroke-width="2.4" fill="none" opacity=".45" stroke-linecap="round"/><path d="M66 42 q14 2 10 14 q-3 6 -10 4" stroke="#fff" stroke-width="5.5" fill="none" stroke-linecap="round"/><path d="M66 42 q14 2 10 14 q-3 6 -10 4" stroke="#e1d8c6" stroke-width="1.2" fill="none"/>'
            + _dots("#7a5a3a", [(24, 78), (30, 82), (36, 79)], 1.6) + '<ellipse cx="74" cy="76" rx="8" ry="3" fill="#d6d9de" transform="rotate(30 74 76)"/>')


def yoghurt():
    inner = ('<rect width="100" height="100" fill="#fffaf0"/><path d="M30 50 Q40 40 50 50 T70 48" stroke="#f2b441" stroke-width="2.6" fill="none" stroke-linecap="round"/>'
             + ''.join(f'<circle cx="{x}" cy="{y}" r="3.6" fill="#4a5aa8"/><circle cx="{x-1}" cy="{y-1}" r="1" fill="#8e9bd8"/>' for x, y in [(40, 40), (48, 36), (56, 42), (62, 52), (36, 54), (52, 58)])
             + ''.join(f'<circle cx="{x}" cy="{y}" r="4.6" fill="#e2405a"/><circle cx="{x}" cy="{y}" r="1.6" fill="#f58a98"/>' for x, y in [(46, 48), (58, 34), (44, 62)]) + _leaf(52, 46, 30, "#5fae58", .8))
    return _bowl("yog", inner, rim="#fffdf8")


def idli():
    inner = '<rect width="100" height="100" fill="#fffdf8"/>'
    plate = _plate()
    idl = ''.join(f'<ellipse cx="{x}" cy="{y+3}" rx="12" ry="9" fill="#e6dcc3"/><ellipse cx="{x}" cy="{y}" rx="12" ry="9" fill="#fffdf6" stroke="#eee5d0" stroke-width="1"/><ellipse cx="{x}" cy="{y-1}" rx="5" ry="3" fill="#f4eedd"/>' for x, y in [(34, 42), (56, 36), (46, 58)])
    sam = '<circle cx="74" cy="64" r="13" fill="#fffaf3" stroke="#e6dcc9" stroke-width="1.2"/><circle cx="74" cy="64" r="9.5" fill="#d9772b"/>' + _dots("#f2c230", [(72, 62), (77, 66)], 1.5) + _dots("#4f9b4b", [(74, 60)], 1.3)
    return plate + idl + sam


def wrap():
    return ('<ellipse cx="50" cy="76" rx="38" ry="7" fill="#6b4a2a" opacity=".12"/><g transform="rotate(-24 50 50)"><rect x="14" y="34" width="72" height="30" rx="15" fill="#ecc98f" stroke="#c9985a" stroke-width="1.6"/><path d="M20 38 q30 -6 60 0" stroke="#f6dfb4" stroke-width="3" fill="none" stroke-linecap="round" opacity=".8"/>'
            '<ellipse cx="82" cy="49" rx="6" ry="14" fill="#fff1d6" stroke="#c9985a" stroke-width="1.4"/>' + _dots("#5aa84f", [(82, 42), (81, 50)], 2.6) + _dots("#e4483f", [(83, 46), (82, 55)], 2.2) + _dots("#f08a2a", [(81, 58)], 2) + '</g>')


def snack_plate():
    sticks = ''.join(f'<rect x="{x}" y="22" width="7" height="34" rx="3.2" fill="#a6d38c" stroke="#7fb868" stroke-width="1" transform="rotate({r} 50 56)"/>' for x, r in [(30, -34), (39, -20), (47, -6)])
    car = ''.join(f'<rect x="{x}" y="22" width="7" height="34" rx="3.2" fill="#f2882a" stroke="#d1691a" stroke-width="1" transform="rotate({r} 50 56)"/>' for x, r in [(46, 8), (54, 22), (62, 36)])
    return (_plate() + sticks + car + '<circle cx="50" cy="62" r="13" fill="#fffaf3" stroke="#e6dcc9" stroke-width="1.2"/><circle cx="50" cy="62" r="9.5" fill="#e8cf9a"/><path d="M44 60 q6 -4 12 0" stroke="#c0552b" stroke-width="2" fill="none" stroke-linecap="round"/>' + _dots("#6bb35a", [(50, 66)], 1.4))


def sweet_potato():
    half = lambda x, y, r: (f'<g transform="rotate({r} {x} {y})"><ellipse cx="{x}" cy="{y+2}" rx="26" ry="14" fill="#6b4a2a" opacity=".13"/><ellipse cx="{x}" cy="{y}" rx="26" ry="14" fill="#9b4a2c"/><ellipse cx="{x}" cy="{y}" rx="22" ry="10.5" fill="#f3a65a"/><ellipse cx="{x-3}" cy="{y-2}" rx="14" ry="5" fill="#f8c183" opacity=".8"/>' + _dots("#d9792b", [(x - 8, y + 2), (x + 4, y + 3), (x + 10, y - 2)], 1.5) + '</g>')
    return half(46, 36, -8) + half(54, 66, 6) + '<path d="M70 28 a9 9 0 0 1 12 12 z" fill="#b6d95a" stroke="#8fb633" stroke-width="1.2"/>' + _dots("#c9552b", [(34, 62), (44, 70), (62, 60)], 1.4)


def khichdi():
    inner = ('<rect width="100" height="100" fill="#f2d98a"/>' + _dots("#e6c46a", [(36, 42), (54, 38), (62, 54), (42, 62), (52, 50)], 3.4)
             + _dots("#6bb35a", [(40, 48), (58, 44), (48, 60), (64, 58)], 2.2)
             + ''.join(f'<circle cx="{x}" cy="{y}" r="2.4" fill="#f08a2a"/>' for x, y in [(46, 42), (56, 58), (36, 56)]) + '<circle cx="50" cy="50" r="5" fill="#fbe9a0"/><circle cx="48.6" cy="48.6" r="1.5" fill="#fff6cf"/>' + _leaf(60, 40, 30, "#5fae58", .8))
    return _bowl("kh", inner)


ART = {"veg_bowl": veg_bowl, "dal": dal, "porridge": porridge, "toast": toast, "salad": salad, "fruit": fruit, "nuts": nuts,
       "soup": soup, "broth": lambda: soup("#e9c46a", True), "curry_roti": curry_roti, "egg": egg, "protein_plate": protein_plate,
       "tea": tea, "yoghurt": yoghurt, "idli": idli, "wrap": wrap, "snack_plate": snack_plate, "sweet_potato": sweet_potato, "khichdi": khichdi}

RULES = [("omelette", "egg"), ("egg", "egg"), ("bhurji", "egg"), ("chilla", "egg"), ("cheela", "egg"),
         ("salmon", "protein_plate"), ("tikka", "protein_plate"), ("tandoori", "protein_plate"), ("fish", "protein_plate"),
         ("clear vegetable soup", "broth"), ("chicken-vegetable soup", "broth"), ("lentil soup", "soup"), ("soup", "soup"),
         ("protein plate", "protein_plate"), ("platter", "snack_plate"), ("lentil", "dal"),
         ("idli", "idli"), ("wrap", "wrap"), ("sandwich", "wrap"),
         ("sweet-potato", "sweet_potato"), ("sticks", "snack_plate"), ("tea", "tea"),
         ("yoghurt", "yoghurt"), ("buttermilk", "yoghurt"), ("overnight", "porridge"), ("oats", "porridge"), ("ragi", "porridge"),
         ("khichdi", "khichdi"), ("dalia", "khichdi"), ("poha", "khichdi"), ("upma", "khichdi"),
         ("toast", "toast"), ("rajma", "curry_roti"), ("curry", "curry_roti"), ("paneer", "curry_roti"), ("chicken", "protein_plate"),
         ("dal", "dal"), ("sambar", "dal"),
         ("salad", "salad"), ("chaat", "salad"), ("fruit", "fruit"), ("nuts", "nuts"), ("chana", "nuts"), ("makhana", "nuts")]


def dish_kind(name):
    n = (name or "").lower()
    if "lauki-chana dal" in n or "chana-vegetable curry" in n or "chana curry" in n:
        return "curry_roti"
    if n.startswith("roasted chana"):
        return "nuts"
    for kw, kind in RULES:
        if re.search(r"\b" + re.escape(kw), n):
            return kind
    return "veg_bowl"


def dish_svg(name, size=None):
    kind = dish_kind(name)
    body = ART[kind]()
    sz = f' width="{size}" height="{size}"' if size else ""
    label = (name or "").replace('"', "")
    return Markup(f'<svg class="dish" viewBox="0 0 100 100"{sz} role="img" aria-label="{label}" xmlns="http://www.w3.org/2000/svg"><rect width="100" height="100" rx="22" fill="{BG[kind]}"/>{body}</svg>')

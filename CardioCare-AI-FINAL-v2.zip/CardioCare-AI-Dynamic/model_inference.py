"""Inference wrapper for the saved Cleveland CatBoost + ANN ensemble.

Improvements over the first prototype
-------------------------------------
* Categorical values are canonicalised to the exact string format that was used
  during training (e.g. ``ca`` = "0.0" rather than "0"), otherwise CatBoost sees
  an unseen category and the prediction silently degrades.
* CatBoost columns are passed in the exact training order.
* Per-patient explanation via CatBoost SHAP values, grouped by the 13 inputs.
* Risk bands relative to the tuned decision threshold.
* ``DemoEnsemble`` - an opt-in placeholder scorer (CARDIOCARE_DEMO=1) so the UI
  can be previewed before ``train_model.py`` has been run. It is NOT the trained
  model and every screen that shows it is labelled accordingly.
"""
from pathlib import Path
import math
import joblib
import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parent
MODEL_DIR = BASE / "models"

BASE_FEATURES = ["age", "sex", "cp", "trestbps", "chol", "fbs", "restecg", "thalach", "exang", "oldpeak", "slope", "ca", "thal"]
NUMERIC_BASE = ["age", "trestbps", "chol", "thalach", "oldpeak"]
CATEGORICAL_BASE = ["sex", "cp", "fbs", "restecg", "exang", "slope", "ca", "thal"]
ENGINEERED_NUMERIC = ["thalach_age_ratio", "chol_age_ratio", "trestbps_age_ratio", "oldpeak_thalach_ratio",
                      "age_oldpeak", "age_thalach", "cp_oldpeak", "exang_oldpeak",
                      "high_oldpeak", "high_trestbps", "high_chol", "low_thalach"]
CATBOOST_FEATURES = NUMERIC_BASE + CATEGORICAL_BASE + ENGINEERED_NUMERIC

# Engineered feature -> the main input it is reported under (SHAP is additive, so grouping is exact).
GROUP_OF = {
    "thalach_age_ratio": "thalach", "age_thalach": "thalach", "low_thalach": "thalach",
    "chol_age_ratio": "chol", "high_chol": "chol",
    "trestbps_age_ratio": "trestbps", "high_trestbps": "trestbps",
    "oldpeak_thalach_ratio": "oldpeak", "age_oldpeak": "oldpeak", "cp_oldpeak": "oldpeak", "high_oldpeak": "oldpeak",
    "exang_oldpeak": "exang",
}

LABELS = {
    "age": "Age", "sex": "Sex", "cp": "Chest pain type", "trestbps": "Resting blood pressure",
    "chol": "Serum cholesterol", "fbs": "Fasting blood sugar", "restecg": "Resting ECG",
    "thalach": "Maximum heart rate", "exang": "Exercise-induced angina", "oldpeak": "ST depression (oldpeak)",
    "slope": "ST slope", "ca": "Major vessels", "thal": "Thalassemia result",
}


def add_features(df):
    d = df.copy()
    for c in NUMERIC_BASE:
        d[c] = pd.to_numeric(d[c], errors="coerce")
    d["thalach_age_ratio"] = d["thalach"] / (d["age"] + 1e-5)
    d["chol_age_ratio"] = d["chol"] / (d["age"] + 1e-5)
    d["trestbps_age_ratio"] = d["trestbps"] / (d["age"] + 1e-5)
    d["oldpeak_thalach_ratio"] = d["oldpeak"] / (d["thalach"] + 1e-5)
    d["age_oldpeak"] = d["age"] * d["oldpeak"]
    d["age_thalach"] = d["age"] * d["thalach"]
    d["cp_oldpeak"] = pd.to_numeric(d["cp"], errors="coerce").fillna(0) * d["oldpeak"]
    d["exang_oldpeak"] = pd.to_numeric(d["exang"], errors="coerce").fillna(0) * d["oldpeak"]
    d["high_oldpeak"] = (d["oldpeak"] > 1.0).astype(int)
    d["high_trestbps"] = (d["trestbps"] >= 140).astype(int)
    d["high_chol"] = (d["chol"] >= 240).astype(int)
    d["low_thalach"] = (d["thalach"] < 120).astype(int)
    for c in CATEGORICAL_BASE:
        d[c] = d[c].astype(str)
    return d.replace([np.inf, -np.inf], np.nan)


def risk_band(probability, threshold):
    """Map the ensemble probability (0-100) to a display band relative to the tuned threshold (0-100)."""
    p, t = float(probability), float(threshold)
    if p < 0.6 * t:
        return {"level": "low", "label": "Lower", "color": "#1D9E75"}
    if p < t:
        return {"level": "moderate", "label": "Borderline", "color": "#BA7517"}
    if p < t + (100 - t) * 0.55:
        return {"level": "elevated", "label": "Elevated", "color": "#D85A30"}
    return {"level": "high", "label": "High", "color": "#A32D2D"}


def _shape_result(pc, pa, probability, threshold, contribs, demo, cfg):
    positive = probability >= threshold
    band = risk_band(probability * 100, threshold * 100)
    return {
        "ready": True,
        "demo": demo,
        "prediction": "Model flagged a heart-disease pattern" if positive else "Model did not flag a heart-disease pattern",
        "probability": round(probability * 100, 1),
        "class": "positive" if positive else "negative",
        "threshold": round(threshold, 3),
        "threshold_pct": round(threshold * 100, 1),
        "catboost_probability": round(pc * 100, 1),
        "ann_probability": round(pa * 100, 1),
        "catboost_weight": round(float(cfg.get("catboost_weight", 0.5)), 2),
        "ann_weight": round(float(cfg.get("ann_weight", 0.5)), 2),
        "level": band["level"], "level_label": band["label"], "color": band["color"],
        "factors": contribs,
        "note": "Research-model output only. It is not a diagnosis or a validated estimate of personal clinical risk.",
    }


def _group_contribs(raw_pairs):
    """raw_pairs: list of (feature_name, shap_value). Returns grouped, normalised list sorted by size."""
    grouped = {}
    for name, val in raw_pairs:
        base = GROUP_OF.get(name, name)
        grouped[base] = grouped.get(base, 0.0) + float(val)
    mx = max([abs(v) for v in grouped.values()] + [1e-9])
    out = [{"key": k, "label": LABELS.get(k, k), "shap": round(v, 3),
            "direction": "raises" if v > 0 else "lowers", "strength": round(abs(v) / mx * 100)}
           for k, v in grouped.items()]
    out.sort(key=lambda r: -abs(r["shap"]))
    return out


class HeartEnsemble:
    def __init__(self):
        from catboost import CatBoostClassifier
        self.cat = CatBoostClassifier()
        self.cat.load_model(str(MODEL_DIR / "catboost_model.cbm"))
        self.ann = joblib.load(MODEL_DIR / "ann_model.joblib")
        self.pre = joblib.load(MODEL_DIR / "ann_preprocessor.joblib")
        self.cfg = joblib.load(MODEL_DIR / "ensemble_config.joblib")
        self.demo = False
        try:
            cats = self.pre.named_transformers_["cat"].categories_
            self._known = {c: set(map(str, v)) for c, v in zip(CATEGORICAL_BASE, cats)}
        except Exception:
            self._known = {}

    @property
    def metrics(self):
        keys = ("oof_auc", "holdout_auc", "holdout_accuracy", "catboost_weight", "ann_weight", "threshold")
        return {k: self.cfg.get(k) for k in keys if k in self.cfg}

    def _canon(self, col, value):
        """Return the category string exactly as it was seen during training."""
        try:
            f = float(value)
        except (TypeError, ValueError):
            return str(value)
        cands = [str(int(f)) if f == int(f) else str(f), str(float(f))]
        known = self._known.get(col, set())
        for c in cands:
            if c in known:
                return c
        return cands[0]

    def _frame(self, values):
        row = {k: values[k] for k in BASE_FEATURES}
        for c in CATEGORICAL_BASE:
            row[c] = self._canon(c, row[c])
        return add_features(pd.DataFrame([row]))

    def predict(self, values, explain=True):
        frame = self._frame(values)
        cb = frame[CATBOOST_FEATURES]
        pc = float(self.cat.predict_proba(cb)[:, 1][0])
        pa = float(self.ann.predict_proba(self.pre.transform(frame))[:, 1][0])
        probability = float(self.cfg["catboost_weight"] * pc + self.cfg["ann_weight"] * pa)
        threshold = float(self.cfg["threshold"])
        contribs = []
        if explain:
            try:
                from catboost import Pool
                pool = Pool(cb, cat_features=CATEGORICAL_BASE)
                sv = self.cat.get_feature_importance(pool, type="ShapValues")[0][:-1]
                contribs = _group_contribs(list(zip(CATBOOST_FEATURES, sv)))
            except Exception:
                contribs = []
        return _shape_result(pc, pa, probability, threshold, contribs, False, self.cfg)


class DemoEnsemble:
    """Placeholder logistic scorer used ONLY when CARDIOCARE_DEMO=1 and no trained model exists."""
    demo = True
    metrics = {}
    cfg = {"catboost_weight": 0.6, "ann_weight": 0.4, "threshold": 0.5}

    @staticmethod
    def _terms(v):
        age, sex, cp = float(v["age"]), int(v["sex"]), int(v["cp"])
        return {
            "age": 0.035 * (age - 54),
            "sex": 0.8 if sex == 1 else 0.0,
            "cp": {1: 0.4, 2: -0.1, 3: -0.3, 4: 1.3}.get(cp, 0.0),
            "trestbps": 0.012 * (float(v["trestbps"]) - 130),
            "chol": 0.004 * (float(v["chol"]) - 240),
            "fbs": 0.2 if int(v["fbs"]) == 1 else 0.0,
            "restecg": {0: 0.0, 1: 0.25, 2: 0.35}.get(int(v["restecg"]), 0.0),
            "thalach": 0.025 * (150 - float(v["thalach"])),
            "exang": 0.9 if int(v["exang"]) == 1 else 0.0,
            "oldpeak": 0.55 * float(v["oldpeak"]),
            "slope": {1: -0.2, 2: 0.5, 3: 0.6}.get(int(v["slope"]), 0.0),
            "ca": 0.8 * int(v["ca"]),
            "thal": {3: -0.2, 6: 0.8, 7: 1.3}.get(int(v["thal"]), 0.0),
        }

    def predict(self, values, explain=True):
        terms = self._terms(values)
        s = sum(terms.values())
        sig = lambda x: 1 / (1 + math.exp(-x))
        pc, pa = sig(0.346 * s - 1.49), sig(0.32 * s - 1.35)
        w = self.cfg["catboost_weight"]
        probability = w * pc + (1 - w) * pa
        contribs = _group_contribs(list(terms.items())) if explain else []
        return _shape_result(pc, pa, probability, self.cfg["threshold"], contribs, True, self.cfg)

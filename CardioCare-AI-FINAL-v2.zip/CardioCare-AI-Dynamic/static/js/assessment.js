(function(){
  var form=document.getElementById('wiz');if(!form)return;
  var steps=[].slice.call(form.querySelectorAll('.step')),stepper=[].slice.call(document.querySelectorAll('#stepper .st'));
  var back=document.getElementById('back'),next=document.getElementById('next'),submit=document.getElementById('submit'),count=document.getElementById('stepcount');
  var cur=1,N=steps.length;
  var fields=[].slice.call(form.querySelectorAll('.field[data-field]'));

  function num(f){return f.querySelector('input[type=number]')}
  function slider(f){return f.querySelector('input[type=range]')}
  function ranges(f){try{return JSON.parse(f.dataset.ranges||'[]')}catch(e){return[]}}
  function val(name){var f=form.querySelector('.field[data-field="'+name+'"]');if(!f)return null;var n=num(f);return n&&n.value!==''?parseFloat(n.value):null}
  function band(f,v){var r=ranges(f);for(var i=0;i<r.length;i++){if(v>=r[i][0]&&v<r[i][1])return{tone:r[i][2],text:r[i][3]}}return null}

  function update(f){
    var n=num(f);if(!n)return;var live=f.querySelector('.live');
    if(n.value===''){live.innerHTML='';return}
    var v=parseFloat(n.value),b=band(f,v),h='';
    if(b)h+='<span class="tone '+b.tone+'">'+b.text+'</span>';
    if(f.dataset.pctage){var age=val('age');if(age){var p=Math.round(v/(220-age)*100);h+='<span>'+p+'% of age-based estimate (220 − age)</span>'}}
    live.innerHTML=h;
  }
  function liveList(){
    var el=document.getElementById('livelist'),h='';
    fields.forEach(function(f){var n=num(f);if(!n||n.value==='')return;var b=band(f,parseFloat(n.value));if(!b)return;
      var ic=b.tone==='ok'?'circle-check':b.tone==='flag'?'alert-octagon':b.tone==='watch'?'alert-triangle':'info-circle';
      h+='<div class="it '+b.tone+'"><i class="ti ti-'+ic+'"></i><span><b>'+f.dataset.label+' '+n.value+'</b> · '+b.text+'</span></div>'});
    el.innerHTML=h||'<div class="it"><i class="ti ti-point"></i>Start entering values to see range checks.</div>';
  }
  fields.forEach(function(f){
    var n=num(f),s=slider(f);if(!n||!s)return;
    s.addEventListener('input',function(){n.value=s.value;f.classList.remove('has-err');update(f);if(f.dataset.field==='age')fields.forEach(function(g){if(g.dataset.pctage)update(g)});liveList()});
    n.addEventListener('input',function(){if(n.value!=='')s.value=n.value;f.classList.remove('has-err');update(f);if(f.dataset.field==='age')fields.forEach(function(g){if(g.dataset.pctage)update(g)});liveList()});
    n.addEventListener('keydown',function(e){if(e.key==='Enter'){e.preventDefault();if(cur<N)next.click()}});
    update(f);
  });
  form.addEventListener('change',function(e){var f=e.target.closest('.field');if(f)f.classList.remove('has-err')});
  liveList();

  function valid(step){
    var bad=null;
    steps[step-1].querySelectorAll('.field[data-field]').forEach(function(f){
      var ok=true,msg='';
      if(f.dataset.radio){ok=!!f.querySelector('input:checked');msg='Choose an option'}
      else{var n=num(f);if(n.value===''){ok=false;msg='Enter a value'}else{var v=parseFloat(n.value);if(isNaN(v)||v<parseFloat(n.min)||v>parseFloat(n.max)){ok=false;msg='Use a value between '+n.min+' and '+n.max}}}
      f.classList.toggle('has-err',!ok);if(!ok){f.querySelector('.f-err').textContent=msg;if(!bad)bad=f}});
    return bad;
  }
  function summary(){
    var h='';fields.forEach(function(f){var t;if(f.dataset.radio){var c=f.querySelector('input:checked');t=c?c.closest('.choice').querySelector('b').textContent:'—'}else{var n=num(f),U={age:'years',resting_blood_pressure:'mm Hg',serum_cholesterol:'mg/dL',maximum_heart_rate_achieved:'bpm',oldpeak:''};t=n.value!==''?(n.value+' '+(U[f.dataset.field]||'')).trim():'—'}
      h+='<tr><td>'+f.dataset.label+'</td><td>'+t+'</td></tr>'});
    document.getElementById('summary').innerHTML=h;
  }
  function show(n){
    cur=n;steps.forEach(function(s,i){s.classList.toggle('active',i===n-1)});
    stepper.forEach(function(s,i){s.classList.toggle('active',i===n-1);s.classList.toggle('done',i<n-1)});
    back.style.visibility=n===1?'hidden':'visible';next.style.display=n===N?'none':'';submit.style.display=n===N?'':'none';
    count.textContent='Step '+n+' of '+N;if(n===N)summary();
    window.scrollTo({top:form.getBoundingClientRect().top+window.scrollY-190,behavior:'smooth'});
  }
  next.addEventListener('click',function(){var b=valid(cur);if(b){b.scrollIntoView({behavior:'smooth',block:'center'});return}show(cur+1)});
  back.addEventListener('click',function(){if(cur>1)show(cur-1)});
  stepper.forEach(function(s){s.addEventListener('click',function(){var to=parseInt(s.dataset.go,10);if(to<=cur){show(to);return}for(var i=cur;i<to;i++){var b=valid(i);if(b){show(i);return}}show(to)})});
  form.addEventListener('submit',function(e){for(var i=1;i<N;i++){var b=valid(i);if(b){e.preventDefault();show(i);return}}});

  document.querySelectorAll('[data-sample]').forEach(function(btn){btn.addEventListener('click',function(){
    var s=(window.CC_SAMPLES||{})[btn.dataset.sample];if(!s)return;
    Object.keys(s).forEach(function(k){var f=form.querySelector('.field[data-field="'+k+'"]');if(!f)return;
      if(f.dataset.radio){var r=f.querySelector('input[value="'+s[k]+'"]');if(r)r.checked=true}else{num(f).value=s[k];slider(f).value=s[k]}f.classList.remove('has-err')});
    fields.forEach(update);liveList();show(N);
  })});

  var firstErr=form.querySelector('.field.has-err');
  if(firstErr){var sec=firstErr.closest('.step');show(steps.indexOf(sec)+1)}else show(1);
})();

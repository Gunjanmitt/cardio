window.CC=(function(){
  var TEAL='#0a8f84',GRID='#e8efef',INK='#5c727a';
  Chart.defaults.font.family="'DM Sans',sans-serif";Chart.defaults.color=INK;
  function base(extra){return Object.assign({responsive:true,maintainAspectRatio:false,interaction:{mode:'index',intersect:false},plugins:{legend:{display:false},tooltip:{backgroundColor:'#12262e',padding:10,cornerRadius:10,titleFont:{weight:'700'}}},scales:{x:{grid:{display:false},ticks:{maxTicksLimit:8}},y:{grid:{color:GRID},border:{display:false}}}},extra||{})}
  function grad(ctx,c1,c2){var g=ctx.createLinearGradient(0,0,0,260);g.addColorStop(0,c1);g.addColorStop(1,c2);return g}
  return {
    risk:function(id,data,onClick){var el=document.getElementById(id);if(!el)return;var ctx=el.getContext('2d');
      new Chart(el,{type:'line',data:{labels:data.map(function(d){return d.label}),datasets:[
        {label:'Model output %',data:data.map(function(d){return d.p}),borderColor:TEAL,backgroundColor:grad(ctx,'rgba(10,143,132,.28)','rgba(10,143,132,0)'),fill:true,tension:.35,pointRadius:5,pointHoverRadius:7,pointBackgroundColor:'#fff',pointBorderColor:TEAL,pointBorderWidth:3,borderWidth:3},
        {label:'Threshold %',data:data.map(function(d){return d.th}),borderColor:'#d85a30',borderDash:[6,6],pointRadius:0,borderWidth:2,fill:false}]},
        options:base({scales:{x:{grid:{display:false}},y:{min:0,max:100,grid:{color:GRID},border:{display:false},ticks:{callback:function(v){return v+'%'}}}},onClick:function(e,els){if(onClick&&els.length)onClick(data[els[0].index].id)}})})},
    bp:function(id,labels,sys,dia){var el=document.getElementById(id);if(!el)return;
      new Chart(el,{type:'line',data:{labels:labels,datasets:[{label:'Systolic',data:sys,borderColor:'#d85a30',backgroundColor:'#d85a30',tension:.3,borderWidth:3,pointRadius:3},{label:'Diastolic',data:dia,borderColor:'#6c8fce',backgroundColor:'#6c8fce',tension:.3,borderWidth:3,pointRadius:3}]},options:base({plugins:{legend:{display:true,position:'bottom',labels:{usePointStyle:true,boxWidth:8}}},scales:{x:{grid:{display:false}},y:{grid:{color:GRID},border:{display:false},suggestedMin:50}}}) })},
    vitals:function(id,labels,sys,dia,pulse){var el=document.getElementById(id);if(!el)return;
      new Chart(el,{type:'line',data:{labels:labels,datasets:[{label:'Systolic',data:sys,borderColor:'#d85a30',backgroundColor:'#d85a30',tension:.3,borderWidth:3,pointRadius:3,spanGaps:true},{label:'Diastolic',data:dia,borderColor:'#6c8fce',backgroundColor:'#6c8fce',tension:.3,borderWidth:3,pointRadius:3,spanGaps:true},{label:'Pulse',data:pulse,borderColor:'#14978a',backgroundColor:'#14978a',tension:.3,borderWidth:2,borderDash:[5,4],pointRadius:2,spanGaps:true}]},options:base({plugins:{legend:{display:true,position:'bottom',labels:{usePointStyle:true,boxWidth:8}}}})})},
    weight:function(id,labels,w){var el=document.getElementById(id);if(!el)return;var ctx=el.getContext('2d');
      new Chart(el,{type:'line',data:{labels:labels,datasets:[{label:'Weight (kg)',data:w,borderColor:TEAL,backgroundColor:grad(ctx,'rgba(10,143,132,.22)','rgba(10,143,132,0)'),fill:true,tension:.35,borderWidth:3,pointRadius:3,spanGaps:true}]},options:base()})}
  };
})();

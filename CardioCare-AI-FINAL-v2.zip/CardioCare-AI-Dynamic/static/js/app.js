(function(){
  // toasts
  document.querySelectorAll('.toasts .flash').forEach(function(el){setTimeout(function(){el.style.opacity='0';el.style.transform='translateY(-6px)';setTimeout(function(){el.remove()},500)},5200)});
  // gauges + bars + counters
  function animate(){
    document.querySelectorAll('[data-gauge] .val').forEach(function(p){setTimeout(function(){p.style.strokeDashoffset=p.dataset.off},120)});
    document.querySelectorAll('[data-w]').forEach(function(el){setTimeout(function(){el.style.width=el.dataset.w+'%'},150)});
    document.querySelectorAll('[data-count]').forEach(function(el){
      var to=parseFloat(el.dataset.count),dec=parseInt(el.dataset.dec||'0',10),t0=null;
      if(isNaN(to))return;
      function step(t){if(!t0)t0=t;var k=Math.min(1,(t-t0)/1300),e=1-Math.pow(1-k,3);el.textContent=(to*e).toFixed(dec).replace(/\.0$/,'');if(k<1)requestAnimationFrame(step);else el.textContent=String(parseFloat(to.toFixed(dec)))}
      requestAnimationFrame(step)});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',animate);else animate();
  // tabs
  document.querySelectorAll('.tab[data-group]').forEach(function(tab){tab.addEventListener('click',function(){
    var g=tab.dataset.group;
    document.querySelectorAll('.tab[data-group="'+g+'"]').forEach(function(t){t.classList.toggle('active',t===tab)});
    document.querySelectorAll('.tab-panel[data-group="'+g+'"]').forEach(function(p){p.classList.toggle('active',p.dataset.id===tab.dataset.target)});
  })});
  // confirm dialogs
  document.querySelectorAll('form[data-confirm]').forEach(function(f){f.addEventListener('submit',function(e){
    if(f.dataset.ok)return;e.preventDefault();
    var d=document.createElement('dialog');d.innerHTML='<h3>Are you sure?</h3><p style="margin:0 0 20px">'+f.dataset.confirm+'</p><div style="display:flex;gap:10px;justify-content:flex-end"><button class="btn outline sm" value="no" style="margin:0">Cancel</button><button class="btn danger sm" value="yes">Yes, continue</button></div>';
    document.body.appendChild(d);d.showModal();
    d.querySelectorAll('button').forEach(function(b){b.addEventListener('click',function(ev){ev.preventDefault();var yes=b.value==='yes';d.close();d.remove();if(yes){f.dataset.ok='1';f.submit()}})});
  })});
  // reveal on scroll
  if('IntersectionObserver' in window){var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}})},{threshold:.15});document.querySelectorAll('.reveal').forEach(function(el){io.observe(el)})}
  else document.querySelectorAll('.reveal').forEach(function(el){el.classList.add('in')});
})();

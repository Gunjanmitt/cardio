// Procedural 3D beating heart (Three.js, bundled locally). Falls back to the static artwork if WebGL is unavailable.
import * as THREE from '../vendor/three.module.min.js';

function hasWebGL() {
  try { const c = document.createElement('canvas'); return !!(c.getContext('webgl2') || c.getContext('webgl')); } catch (e) { return false; }
}
const gauss = (x, m, s) => Math.exp(-((x - m) * (x - m)) / (2 * s * s));

function heartGeometry() {
  // Smooth implicit heart surface: (x^2 + 9/4 y^2 + z^2 - 1)^3 - x^2 z^3 - 9/80 y^2 z^3 = 0   (z is up).
  // The surface is meshed by casting rays from the centre and bisecting for the first crossing.
  const f = (x, y, z) => Math.pow(x * x + 2.25 * y * y + z * z - 1, 3) - x * x * z * z * z - 0.1125 * y * y * z * z * z;
  const U = 90, V = 180, SC = 1.5, pos = [], col = [], idx = [];
  const top = new THREE.Color('#e04552'), bottom = new THREE.Color('#8a1421'), c = new THREE.Color();
  const dir = new THREE.Vector3();
  for (let i = 0; i <= U; i++) {
    const phi = (i / U) * Math.PI;                      // 0 = straight up
    for (let j = 0; j < V; j++) {
      const th = (j / V) * Math.PI * 2;
      dir.set(Math.sin(phi) * Math.cos(th), Math.sin(phi) * Math.sin(th), Math.cos(phi));
      let lo = 0, hi = 2.2, prev = 0;
      for (let r = 0.02; r <= 2.2; r += 0.02) { if (f(dir.x * r, dir.y * r, dir.z * r) > 0) { hi = r; lo = prev; break; } prev = r; }
      for (let k = 0; k < 24; k++) { const m = (lo + hi) / 2; if (f(dir.x * m, dir.y * m, dir.z * m) > 0) hi = m; else lo = m; }
      const r = (lo + hi) / 2, x = dir.x * r, y = dir.y * r, z = dir.z * r;
      pos.push(x * SC, (z - 0.1) * SC, y * SC * 1.05);
      c.copy(bottom).lerp(top, THREE.MathUtils.clamp((z + 1) / 2.1, 0, 1));
      col.push(c.r, c.g, c.b);
    }
  }
  for (let i = 0; i < U; i++) for (let j = 0; j < V; j++) {
    const a = i * V + j, b = i * V + (j + 1) % V, d = (i + 1) * V + j, e = (i + 1) * V + (j + 1) % V;
    idx.push(a, b, d, b, e, d);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}

function tube(points, radius, color) {
  const curve = new THREE.CatmullRomCurve3(points.map(p => new THREE.Vector3(...p)));
  const m = new THREE.Mesh(new THREE.TubeGeometry(curve, 40, radius, 20, false),
    new THREE.MeshPhysicalMaterial({ color, roughness: 0.38, clearcoat: 0.6, clearcoatRoughness: 0.3 }));
  return m;
}

function glowTexture() {
  const c = document.createElement('canvas'); c.width = c.height = 256;
  const g = c.getContext('2d'), r = g.createRadialGradient(128, 128, 0, 128, 128, 128);
  r.addColorStop(0, 'rgba(255,140,120,0.85)'); r.addColorStop(0.45, 'rgba(255,110,100,0.25)'); r.addColorStop(1, 'rgba(255,110,100,0)');
  g.fillStyle = r; g.fillRect(0, 0, 256, 256);
  return new THREE.CanvasTexture(c);
}

function envMap(renderer) {
  const env = new THREE.Scene(); env.background = new THREE.Color('#10484a');
  const panel = (w, h, x, y, z, i) => {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ color: new THREE.Color(i, i, i), side: THREE.DoubleSide }));
    m.position.set(x, y, z); m.lookAt(0, 0, 0); env.add(m);
  };
  panel(10, 6, 6, 8, 6, 4); panel(4, 10, -9, 2, 4, 2.4); panel(8, 3, 0, -8, 5, 1.2); panel(6, 6, 0, 3, -9, 1.6);
  const pm = new THREE.PMREMGenerator(renderer);
  const tex = pm.fromScene(env, 0.04).texture; pm.dispose(); return tex;
}

function syncEcg(el, T) {
  const root = el.closest('section, .card, .land-hero') || document;
  root.querySelectorAll('.ecg .live').forEach(p => { p.style.animationDuration = (T * 4) + 's'; p.style.animationDelay = (T * 0.5) + 's'; });
}

function init(el) {
  if (!hasWebGL()) return;
  const bpm = Math.max(40, Math.min(160, parseFloat(el.dataset.bpm) || 72)), T = 60 / bpm;
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let renderer;
  try { renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'low-power' }); } catch (e) { return; }
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 0.95;
  const canvas = renderer.domElement; canvas.setAttribute('aria-hidden', 'true'); canvas.className = 'heart3d-canvas';
  el.appendChild(canvas);

  const scene = new THREE.Scene();
  scene.environment = envMap(renderer);
  const camera = new THREE.PerspectiveCamera(30, 1, 0.1, 50); camera.position.set(0, 0.25, 9.2);

  scene.add(new THREE.HemisphereLight(0xffffff, 0x5a2a2a, 0.5));
  const key = new THREE.DirectionalLight(0xffffff, 1.7); key.position.set(3, 4, 5); scene.add(key);
  const warm = new THREE.PointLight(0xff8a7a, 12, 12); warm.position.set(-3, -1, 3); scene.add(warm);
  const rim = new THREE.PointLight(0x13d1bd, 18, 12); rim.position.set(3.5, 1.2, -2.5); scene.add(rim);

  const group = new THREE.Group(); scene.add(group);
  const mat = new THREE.MeshPhysicalMaterial({ vertexColors: true, roughness: 0.3, metalness: 0.0, clearcoat: 0.9, clearcoatRoughness: 0.18,
    sheen: 0.35, sheenColor: new THREE.Color('#ff8a7a'), envMapIntensity: 0.75, emissive: new THREE.Color('#ff2d2d'), emissiveIntensity: 0.05 });
  const heart = new THREE.Mesh(heartGeometry(), mat); group.add(heart);
  const red = '#d8505c', blue = '#5f7fcf';
  group.add(tube([[0.18, 1.0, -0.05], [0.24, 1.55, -0.05], [0.12, 2.05, 0.0], [-0.3, 2.25, 0.05], [-0.72, 2.05, 0.1]], 0.16, red));
  group.add(tube([[-0.2, 1.0, 0.42], [-0.3, 1.5, 0.46], [-0.6, 1.85, 0.4], [-0.95, 1.9, 0.32]], 0.11, blue));
  group.add(tube([[0.7, 0.95, -0.28], [0.8, 1.45, -0.28], [0.76, 2.0, -0.22]], 0.105, blue));
  group.position.y = -0.05;

  const glow = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture(), blending: THREE.AdditiveBlending, transparent: true, depthWrite: false, opacity: 0.5 }));
  glow.position.z = -1.2; glow.scale.set(3.6, 3.6, 1); scene.add(glow);

  const N = 140, pts = new Float32Array(N * 3), seeds = [];
  for (let i = 0; i < N; i++) seeds.push({ a: Math.random() * 6.283, r: 2.0 + Math.random() * 0.7, y: (Math.random() - 0.5) * 2.6, s: 0.25 + Math.random() * 0.5 });
  const pg = new THREE.BufferGeometry(); pg.setAttribute('position', new THREE.BufferAttribute(pts, 3));
  const particles = new THREE.Points(pg, new THREE.PointsMaterial({ color: 0xffd9d2, size: 0.06, transparent: true, opacity: 0.75, blending: THREE.AdditiveBlending, depthWrite: false }));
  scene.add(particles);

  function resize() {
    const w = Math.max(60, el.clientWidth), h = Math.max(60, el.clientHeight);
    renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix();
  }
  new ResizeObserver(resize).observe(el); resize();

  let mx = 0, my = 0;
  window.addEventListener('pointermove', e => { mx = (e.clientX / window.innerWidth - 0.5) * 2; my = (e.clientY / window.innerHeight - 0.5) * 2; }, { passive: true });
  syncEcg(el, T);

  let visible = true; new IntersectionObserver(es => { visible = es[0].isIntersecting; }).observe(el);
  const clock = new THREE.Clock();
  function frame() {
    requestAnimationFrame(frame);
    if (!visible || document.hidden) return;
    const t = clock.getElapsedTime();
    const p = (t % T) / T, beat = reduce ? 0 : gauss(p, 0.06, 0.035) + 0.65 * gauss(p, 0.3, 0.045);
    const s = 1 + 0.11 * beat;
    group.scale.set(s, s * (1 - 0.025 * beat), s);
    mat.emissiveIntensity = 0.04 + 0.55 * beat;
    glow.material.opacity = 0.28 + 0.35 * beat; glow.scale.setScalar(3.4 + 0.5 * beat);
    if (!reduce) {
      group.rotation.y += ((Math.sin(t * 0.6) * 0.4 + mx * 0.45) - group.rotation.y) * 0.06;
      group.rotation.x += ((-0.08 + my * 0.2) - group.rotation.x) * 0.06;
      group.position.y = -0.05 + Math.sin(t * 1.2) * 0.04;
    }
    const arr = pg.attributes.position.array;
    for (let i = 0; i < N; i++) { const q = seeds[i], a = q.a + t * q.s * (0.6 + beat * 0.8); arr[i * 3] = Math.cos(a) * q.r; arr[i * 3 + 1] = q.y + Math.sin(t * q.s + i) * 0.15; arr[i * 3 + 2] = Math.sin(a) * q.r * 0.6 - 0.3; }
    pg.attributes.position.needsUpdate = true;
    renderer.render(scene, camera);
  }
  frame();
  el.classList.add('live');
}

document.querySelectorAll('.heart3d').forEach(init);

Local assets: Manrope and DM Sans fonts, Tabler Icons (MIT) and Chart.js (MIT) are bundled in static/vendor. Heart artwork is from the original prototype.

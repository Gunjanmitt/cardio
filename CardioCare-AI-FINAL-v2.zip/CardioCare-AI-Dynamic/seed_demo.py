"""Create a demo account with sample history so every screen has content.

    python seed_demo.py            (uses your trained model if present)
    python seed_demo.py --demo     (uses the placeholder demo scorer)

Login: demo@cardiocare.app / Demo@12345
"""
import json, random, sys
from datetime import datetime, timedelta
from werkzeug.security import generate_password_hash
import app as A

EMAIL, PASSWORD = "demo@cardiocare.app", "Demo@12345"
RUNS = [  # (days ago, patient values) - gradually improving fictional trajectory
    (75, dict(age=52, sex=1, chest_pain_type=4, resting_blood_pressure=148, serum_cholesterol=262, fasting_blood_sugar=1, resting_electrocardiographic_results=1, maximum_heart_rate_achieved=122, exercise_induced_angina=1, oldpeak=2.2, slope=2, number_of_major_vessels=1, thal=7)),
    (58, dict(age=52, sex=1, chest_pain_type=4, resting_blood_pressure=142, serum_cholesterol=248, fasting_blood_sugar=1, resting_electrocardiographic_results=1, maximum_heart_rate_achieved=128, exercise_induced_angina=1, oldpeak=1.9, slope=2, number_of_major_vessels=1, thal=7)),
    (41, dict(age=52, sex=1, chest_pain_type=3, resting_blood_pressure=136, serum_cholesterol=232, fasting_blood_sugar=0, resting_electrocardiographic_results=1, maximum_heart_rate_achieved=136, exercise_induced_angina=0, oldpeak=1.4, slope=2, number_of_major_vessels=1, thal=6)),
    (26, dict(age=52, sex=1, chest_pain_type=3, resting_blood_pressure=130, serum_cholesterol=218, fasting_blood_sugar=0, resting_electrocardiographic_results=0, maximum_heart_rate_achieved=146, exercise_induced_angina=0, oldpeak=1.0, slope=1, number_of_major_vessels=0, thal=3)),
    (12, dict(age=52, sex=1, chest_pain_type=2, resting_blood_pressure=126, serum_cholesterol=204, fasting_blood_sugar=0, resting_electrocardiographic_results=0, maximum_heart_rate_achieved=154, exercise_induced_angina=0, oldpeak=0.6, slope=1, number_of_major_vessels=0, thal=3)),
    (2, dict(age=52, sex=1, chest_pain_type=3, resting_blood_pressure=122, serum_cholesterol=196, fasting_blood_sugar=0, resting_electrocardiographic_results=0, maximum_heart_rate_achieved=160, exercise_induced_angina=0, oldpeak=0.3, slope=1, number_of_major_vessels=0, thal=3)),
]


def main():
    with A.db() as con:
        old = con.execute("SELECT id FROM users WHERE email=?", (EMAIL,)).fetchone()
        if old:
            for t in ("vitals", "assessments", "profiles"):
                con.execute(f"DELETE FROM {t} WHERE user_id=?", (old["id"],))
            con.execute("DELETE FROM users WHERE id=?", (old["id"],))
        uid = con.execute("INSERT INTO users(name,email,password,created_at) VALUES(?,?,?,?)",
                          ("Aarav Sharma", EMAIL, generate_password_hash(PASSWORD), datetime.now().isoformat(timespec="seconds"))).lastrowid
        con.execute("""INSERT INTO profiles(user_id,height,weight,activity,diet,allergies,conditions,goal,meals,updated_at)
                       VALUES(?,?,?,?,?,?,?,?,?,?)""", (uid, 172, 78, "light", "vegetarian", "peanuts", "Mild high blood pressure", "heart_health", "4", datetime.now().isoformat()))
        for days, x in RUNS:
            r = A.predict(x)
            when = (datetime.now() - timedelta(days=days)).strftime("%d %b %Y · %I:%M %p")
            if r.get("ready"):
                d = {k: r[k] for k in ("catboost_probability", "ann_probability", "threshold", "threshold_pct", "catboost_weight", "ann_weight", "level", "level_label", "color", "factors", "demo", "class", "note")}
                con.execute("""INSERT INTO assessments(user_id,payload,prediction,probability,model_type,created_at,details,risk_level,note) VALUES(?,?,?,?,?,?,?,?,?)""",
                            (uid, json.dumps(x), r["prediction"], r["probability"], "Demo scorer (not the trained model)" if r["demo"] else "CatBoost + ANN ensemble", when, json.dumps(d), r["level"], ""))
            else:
                con.execute("""INSERT INTO assessments(user_id,payload,prediction,probability,model_type,created_at) VALUES(?,?,?,?,?,?)""",
                            (uid, json.dumps(x), r["message"], None, "not_configured", when))
        random.seed(7)
        for i in range(14, 0, -1):
            t = (datetime.now() - timedelta(days=i, hours=random.randint(0, 3))).isoformat(timespec="minutes")
            con.execute("INSERT INTO vitals(user_id,logged_at,systolic,diastolic,pulse,weight,glucose,note) VALUES(?,?,?,?,?,?,?,?)",
                        (uid, t, round(142 - (14 - i) * 1.0 + random.randint(-4, 4)), round(90 - (14 - i) * .45 + random.randint(-3, 3)),
                         random.randint(68, 80), round(79.4 - (14 - i) * .1, 1), random.randint(88, 104), ""))
    print("Demo account ready ->", EMAIL, "/", PASSWORD, "| model:", A.model_status())


if __name__ == "__main__":
    main()

"""CardioCare AI - Flask application (CatBoost + ANN heart-disease research ensemble).

Research / education software. Not a medical device, not for diagnosis or treatment.
"""
from flask import (Flask, render_template, request, redirect, url_for, session, flash,
                   jsonify, abort, Response, g)
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
from functools import wraps
import sqlite3, os, io, csv, json, secrets, sys, time

import wellness
from dish_art import dish_svg
from model_inference import BASE_FEATURES, risk_band

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, "database", "cardio.db")
MODEL_PATH = os.path.join(BASE, "models", "ensemble_config.joblib")
os.makedirs(os.path.dirname(DB), exist_ok=True)

if "--demo" in sys.argv:
    os.environ["CARDIOCARE_DEMO"] = "1"


def _secret_key():
    env = os.environ.get("SECRET_KEY")
    if env:
        return env
    path = os.path.join(BASE, "database", "secret.key")
    if os.path.exists(path):
        return open(path).read().strip()
    key = secrets.token_hex(32)
    with open(path, "w") as fh:
        fh.write(key)
    return key


app = Flask(__name__)
app.secret_key = _secret_key()
app.config.update(SESSION_COOKIE_SAMESITE="Lax", SESSION_COOKIE_HTTPONLY=True,
                  PERMANENT_SESSION_LIFETIME=timedelta(days=14), MAX_CONTENT_LENGTH=256 * 1024)

# ------------------------------------------------------------------ database

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    return con


def _add_column(con, table, column, ddl):
    cols = [r[1] for r in con.execute(f"PRAGMA table_info({table})")]
    if column not in cols:
        con.execute(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}")


def init_db():
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL, created_at TEXT NOT NULL)""")
        con.execute("""CREATE TABLE IF NOT EXISTS profiles(
            user_id INTEGER PRIMARY KEY, height REAL, weight REAL, activity TEXT DEFAULT 'light',
            diet TEXT DEFAULT 'vegetarian', allergies TEXT DEFAULT '', conditions TEXT DEFAULT '',
            goal TEXT DEFAULT 'heart_health', meals TEXT DEFAULT '3', updated_at TEXT,
            FOREIGN KEY(user_id) REFERENCES users(id))""")
        con.execute("""CREATE TABLE IF NOT EXISTS assessments(
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, payload TEXT NOT NULL,
            prediction TEXT NOT NULL, probability REAL, model_type TEXT NOT NULL, created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id))""")
        con.execute("""CREATE TABLE IF NOT EXISTS vitals(
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, logged_at TEXT NOT NULL,
            systolic REAL, diastolic REAL, pulse REAL, weight REAL, glucose REAL, note TEXT DEFAULT '',
            FOREIGN KEY(user_id) REFERENCES users(id))""")
        # migrations for databases created by the first prototype
        _add_column(con, "assessments", "details", "TEXT")
        _add_column(con, "assessments", "risk_level", "TEXT")
        _add_column(con, "assessments", "note", "TEXT DEFAULT ''")


init_db()

# ------------------------------------------------------------------ security helpers

def csrf_token():
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_hex(16)
    return session["_csrf"]


app.jinja_env.globals["csrf_token"] = csrf_token


def gauge_geo(p, t=50, r=80):
    """Geometry for the semicircle gauge: arc length, dash offset and threshold tick coordinates."""
    import math
    arc = math.pi * r
    p = max(0.0, min(100.0, float(p or 0)))
    ang = math.pi * (1 - float(t) / 100.0)
    cx, cy = 100, 100
    return {"len": round(arc, 2), "off": round(arc * (1 - p / 100), 2),
            "x1": round(cx + (r - 11) * math.cos(ang), 2), "y1": round(cy - (r - 11) * math.sin(ang), 2),
            "x2": round(cx + (r + 11) * math.cos(ang), 2), "y2": round(cy - (r + 11) * math.sin(ang), 2)}


app.jinja_env.globals["gauge_geo"] = gauge_geo


def _ecg_path():
    d = "M0 46 "
    for i in range(4):
        o = i * 300
        d += f"H{o+110} q8 -10 18 0 H{o+150} l8 8 l14 -44 l16 70 l10 -34 H{o+238} q14 -16 30 0 "
    return d + "H1200"


app.jinja_env.globals["ECG_PATH"] = _ecg_path()


def spark(values, w=92, h=40):
    """SVG path for a tiny sparkline from a list of numbers (None values skipped)."""
    v = [float(x) for x in values if x is not None]
    if len(v) < 2:
        return ""
    lo, hi = min(v), max(v)
    span = (hi - lo) or 1.0
    pts = [(2 + i * (w - 4) / (len(v) - 1), 4 + (h - 8) * (1 - (x - lo) / span)) for i, x in enumerate(v)]
    return " ".join(f"{'M' if i == 0 else 'L'}{x:.1f} {y:.1f}" for i, (x, y) in enumerate(pts))


app.jinja_env.globals["spark"] = spark
app.jinja_env.globals["dish"] = dish_svg


@app.before_request
def csrf_protect():
    if request.method == "POST":
        sent = request.form.get("_csrf") or request.headers.get("X-CSRF-Token") or ""
        if not sent or not secrets.compare_digest(sent, session.get("_csrf", "")):
            if request.path.startswith("/api/"):
                return jsonify(error="Session expired. Refresh the page and try again."), 400
            abort(400)


@app.after_request
def security_headers(resp):
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
    resp.headers.setdefault("Referrer-Policy", "same-origin")
    return resp


_FAILS = {}


def _throttled(key):
    now = time.time()
    hits = [t for t in _FAILS.get(key, []) if now - t < 300]
    _FAILS[key] = hits
    return len(hits) >= 6


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("user_id"):
            flash("Sign in to continue.", "info")
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper


def current_user():
    if not session.get("user_id"):
        return None
    with db() as con:
        return con.execute("SELECT id,name,email,created_at FROM users WHERE id=?", (session["user_id"],)).fetchone()

# ------------------------------------------------------------------ model

_ENSEMBLE = None
_LOAD_FAILED = False


def load_model():
    """Return the trained ensemble, the opt-in demo scorer, or None."""
    global _ENSEMBLE, _LOAD_FAILED
    if _ENSEMBLE is not None:
        return _ENSEMBLE
    if os.path.exists(MODEL_PATH) and not _LOAD_FAILED:
        try:
            from model_inference import HeartEnsemble
            _ENSEMBLE = HeartEnsemble()
            return _ENSEMBLE
        except Exception as exc:  # noqa
            _LOAD_FAILED = True
            app.logger.exception("Could not load trained ensemble: %s", exc)
    if os.environ.get("CARDIOCARE_DEMO") == "1":
        from model_inference import DemoEnsemble
        _ENSEMBLE = DemoEnsemble()
        return _ENSEMBLE
    return None


def model_status():
    m = load_model()
    if m is None:
        return "missing"
    return "demo" if getattr(m, "demo", False) else "ready"


def predict(features, explain=True):
    model = load_model()
    if model is None:
        return {"ready": False, "message": "The CatBoost + ANN ensemble is not trained yet. Run python train_model.py first."}
    mapped = {"age": features["age"], "sex": features["sex"], "cp": features["chest_pain_type"],
              "trestbps": features["resting_blood_pressure"], "chol": features["serum_cholesterol"],
              "fbs": features["fasting_blood_sugar"], "restecg": features["resting_electrocardiographic_results"],
              "thalach": features["maximum_heart_rate_achieved"], "exang": features["exercise_induced_angina"],
              "oldpeak": features["oldpeak"], "slope": features["slope"],
              "ca": features["number_of_major_vessels"], "thal": features["thal"]}
    return model.predict(mapped, explain=explain)

# ------------------------------------------------------------------ validation

FIELD_SPECS = {  # name: (type, min, max, allowed)
    "age": (int, 18, 100, None), "sex": (int, None, None, {0, 1}),
    "chest_pain_type": (int, None, None, {1, 2, 3, 4}),
    "resting_blood_pressure": (float, 70, 250, None), "serum_cholesterol": (float, 80, 650, None),
    "fasting_blood_sugar": (int, None, None, {0, 1}),
    "resting_electrocardiographic_results": (int, None, None, {0, 1, 2}),
    "maximum_heart_rate_achieved": (float, 60, 230, None), "exercise_induced_angina": (int, None, None, {0, 1}),
    "oldpeak": (float, 0, 8, None), "slope": (int, None, None, {1, 2, 3}),
    "number_of_major_vessels": (int, None, None, {0, 1, 2, 3}), "thal": (int, None, None, {3, 6, 7}),
}
FIELD_NICE = {"age": "Age", "sex": "Sex", "chest_pain_type": "Chest pain type", "resting_blood_pressure": "Resting blood pressure",
              "serum_cholesterol": "Cholesterol", "fasting_blood_sugar": "Fasting blood sugar",
              "resting_electrocardiographic_results": "Resting ECG", "maximum_heart_rate_achieved": "Maximum heart rate",
              "exercise_induced_angina": "Exercise-induced angina", "oldpeak": "ST depression", "slope": "ST slope",
              "number_of_major_vessels": "Major vessels", "thal": "Thalassemia"}
TRAIN_RANGE = {"age": (29, 77), "resting_blood_pressure": (94, 200), "serum_cholesterol": (126, 564),
               "maximum_heart_rate_achieved": (71, 202), "oldpeak": (0, 6.2)}


def parse_assessment(form):
    values, errors = {}, {}
    for name, (typ, lo, hi, allowed) in FIELD_SPECS.items():
        raw = (form.get(name) or "").strip()
        if raw == "":
            errors[name] = "Required"
            continue
        try:
            v = typ(float(raw)) if typ is int else float(raw)
        except ValueError:
            errors[name] = "Enter a number"
            continue
        if allowed is not None and v not in allowed:
            errors[name] = "Choose an option"
        elif lo is not None and not (lo <= v <= hi):
            errors[name] = f"Use a value between {lo} and {hi}"
        else:
            values[name] = v
    return values, errors


def range_notes(payload):
    notes = []
    for k, (lo, hi) in TRAIN_RANGE.items():
        try:
            v = float(payload[k])
        except (KeyError, TypeError, ValueError):
            continue
        if v < lo or v > hi:
            notes.append(f"{FIELD_NICE[k]} ({v:g}) is outside the range the model saw in training ({lo:g}-{hi:g}), so the output is less reliable.")
    return notes

# ------------------------------------------------------------------ data helpers

def get_profile(uid):
    with db() as con:
        r = con.execute("SELECT * FROM profiles WHERE user_id=?", (uid,)).fetchone()
    return dict(r) if r else {}


def short_date(s):
    return (s or "").split(" · ")[0]


def row_to_assessment(row):
    """Normalise a DB row (including legacy prototype rows) to a dict for templates."""
    a = dict(row)
    a["payload"] = json.loads(a["payload"])
    d = json.loads(a["details"]) if a.get("details") else None
    a["details"] = d
    a["short_date"] = short_date(a["created_at"])
    if d:
        a["level"], a["level_label"], a["color"] = d.get("level"), d.get("level_label"), d.get("color")
        a["demo"] = bool(d.get("demo"))
    else:
        a["level"], a["level_label"], a["color"], a["demo"] = None, None, "#888780", False
        if a.get("probability") is not None:
            b = risk_band(a["probability"], 50)
            a["level"], a["level_label"], a["color"] = b["level"], b["label"], b["color"]
    a["scored"] = a.get("probability") is not None
    a["mode"] = ("Demo scorer" if a["demo"] else ("Trained ensemble" if a["scored"] else "Not scored"))
    return a


def user_assessments(uid, limit=None):
    sql = "SELECT * FROM assessments WHERE user_id=? ORDER BY id DESC"
    if limit:
        sql += f" LIMIT {int(limit)}"
    with db() as con:
        return [row_to_assessment(r) for r in con.execute(sql, (uid,)).fetchall()]


def user_vitals(uid, limit=60):
    with db() as con:
        rows = con.execute("SELECT * FROM vitals WHERE user_id=? ORDER BY logged_at DESC, id DESC LIMIT ?", (uid, limit)).fetchall()
    out = []
    for r in rows:
        v = dict(r)
        v["bp"] = wellness.bp_category(v["systolic"], v["diastolic"]) if v["systolic"] and v["diastolic"] else None
        try:
            v["label"] = datetime.fromisoformat(v["logged_at"]).strftime("%d %b")
            v["full"] = datetime.fromisoformat(v["logged_at"]).strftime("%d %b %Y, %I:%M %p")
        except ValueError:
            v["label"] = v["full"] = v["logged_at"]
        out.append(v)
    return out


@app.context_processor
def inject_globals():
    return {"model_status": model_status() if session.get("user_id") else None, "year": datetime.now().year}

# ------------------------------------------------------------------ public pages

@app.route("/")
def index():
    if session.get("user_id"):
        return redirect(url_for("dashboard"))
    m = load_model()
    return render_template("landing.html", metrics=getattr(m, "metrics", {}) if m and not getattr(m, "demo", False) else {})


@app.route("/model")
def model_info():
    m = load_model()
    metrics = getattr(m, "metrics", {}) if m else {}
    return render_template("model.html", metrics=metrics, status=model_status(),
                           features=[(k, v) for k, v in FIELD_NICE.items()])


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not name or "@" not in email or len(password) < 8:
            flash("Enter your name, a valid email and a password of at least 8 characters.", "error")
        else:
            try:
                with db() as con:
                    cur = con.execute("INSERT INTO users(name,email,password,created_at) VALUES(?,?,?,?)",
                                      (name, email, generate_password_hash(password), datetime.now().isoformat(timespec="seconds")))
                    uid = cur.lastrowid
                    con.execute("INSERT INTO profiles(user_id,updated_at) VALUES(?,?)", (uid, datetime.now().isoformat()))
                session.clear()
                session["user_id"], session["name"] = uid, name
                flash("Your account is ready. Complete your profile to personalise your plan.", "success")
                return redirect(url_for("profile"))
            except sqlite3.IntegrityError:
                flash("An account with this email already exists.", "error")
    return render_template("auth.html", mode="register")


@app.route("/login", methods=["GET", "POST"])
def login():
    if session.get("user_id") and request.method == "GET":
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        key = f"{request.remote_addr}:{email}"
        if _throttled(key):
            flash("Too many attempts. Wait a few minutes and try again.", "error")
            return render_template("auth.html", mode="login")
        with db() as con:
            user = con.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        if user and check_password_hash(user["password"], request.form.get("password", "")):
            session.clear()
            session["user_id"], session["name"] = user["id"], user["name"]
            _FAILS.pop(key, None)
            return redirect(url_for("dashboard"))
        _FAILS.setdefault(key, []).append(time.time())
        flash("Email or password is incorrect.", "error")
    return render_template("auth.html", mode="login")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

# ------------------------------------------------------------------ profile

@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    user = current_user()
    p = get_profile(user["id"])
    if request.method == "POST":
        def num(name, lo, hi):
            try:
                v = float(request.form.get(name) or "")
                return v if lo <= v <= hi else None
            except ValueError:
                return None
        h, w = num("height", 100, 250), num("weight", 25, 300)
        if (request.form.get("height") and h is None) or (request.form.get("weight") and w is None):
            flash("Height should be 100-250 cm and weight 25-300 kg.", "error")
            return redirect(url_for("profile"))
        diet = request.form.get("diet", "vegetarian")
        activity = request.form.get("activity", "light")
        data = (h, w, activity if activity in wellness.BASE_MINUTES else "light",
                diet if diet in wellness.DIET_LEVEL else "vegetarian",
                request.form.get("allergies", "").strip()[:300], request.form.get("conditions", "").strip()[:500],
                request.form.get("goal", "heart_health"), request.form.get("meals", "3") if request.form.get("meals") in ("2", "3", "4", "5") else "3",
                datetime.now().isoformat(timespec="seconds"), user["id"])
        with db() as con:
            con.execute("""UPDATE profiles SET height=?,weight=?,activity=?,diet=?,allergies=?,conditions=?,goal=?,meals=?,updated_at=? WHERE user_id=?""", data)
        flash("Profile saved. Your wellness plan has been refreshed.", "success")
        return redirect(url_for("recommendations"))
    return render_template("profile.html", p=p, user=user, bmi=wellness.bmi_info(p.get("height"), p.get("weight")))


@app.route("/account/delete", methods=["POST"])
@login_required
def delete_account():
    uid = session["user_id"]
    if request.form.get("confirm", "").strip().lower() != "delete":
        flash("Type DELETE to confirm account removal.", "error")
        return redirect(url_for("profile"))
    with db() as con:
        for t in ("vitals", "assessments", "profiles"):
            con.execute(f"DELETE FROM {t} WHERE user_id=?", (uid,))
        con.execute("DELETE FROM users WHERE id=?", (uid,))
    session.clear()
    flash("Your account and all saved data were deleted.", "info")
    return redirect(url_for("index"))

# ------------------------------------------------------------------ dashboard

def _setup_steps(profile, n_assess, n_vitals):
    return [
        {"label": "Complete your profile", "done": bool(profile.get("height") and profile.get("weight")), "href": url_for("profile"), "icon": "ti-user-check"},
        {"label": "Run a heart assessment", "done": n_assess > 0, "href": url_for("assessment"), "icon": "ti-stethoscope"},
        {"label": "Log your first vitals", "done": n_vitals > 0, "href": url_for("tracker"), "icon": "ti-activity"},
    ]


@app.route("/dashboard")
@login_required
def dashboard():
    user = current_user()
    p = get_profile(user["id"])
    assessments = user_assessments(user["id"])
    vitals = user_vitals(user["id"], 30)
    latest = assessments[0] if assessments else None
    prev = assessments[1] if len(assessments) > 1 else None
    delta = None
    if latest and prev and latest["scored"] and prev["scored"]:
        delta = round(latest["probability"] - prev["probability"], 1)
    trend = [{"label": a["short_date"], "p": a["probability"], "th": (a["details"] or {}).get("threshold_pct", 50)}
             for a in reversed(assessments[:12]) if a["scored"]]
    lv = vitals[0] if vitals else None
    steps = _setup_steps(p, len(assessments), len(vitals))
    review_counts = None
    if latest:
        try:
            review_counts = wellness.count_tones(wellness.input_review(latest["payload"]))
        except (KeyError, ValueError):
            review_counts = None
    plan = wellness.build_plan(p, latest["payload"] if latest else None, latest["level"] if latest else None)
    wd = datetime.now().weekday()
    return render_template("dashboard.html", plan=plan, today=plan["meals"]["week"][wd], move=plan["exercise"]["days"][wd],
                           user=user, profile=p, latest=latest, delta=delta, total=len(assessments),
                           recent=assessments[:5], trend=trend, vitals=vitals[:14][::-1], last_vital=lv,
                           bmi=wellness.bmi_info(p.get("height"), p.get("weight")), steps=steps,
                           progress=int(100 * sum(s["done"] for s in steps) / len(steps)),
                           tip=wellness.daily_tip(), review_counts=review_counts)

# ------------------------------------------------------------------ assessment

SAMPLES = {
    "healthy": {"age": 41, "sex": 0, "chest_pain_type": 3, "resting_blood_pressure": 118, "serum_cholesterol": 192, "fasting_blood_sugar": 0,
                "resting_electrocardiographic_results": 0, "maximum_heart_rate_achieved": 172, "exercise_induced_angina": 0, "oldpeak": 0.2,
                "slope": 1, "number_of_major_vessels": 0, "thal": 3},
    "concern": {"age": 63, "sex": 1, "chest_pain_type": 4, "resting_blood_pressure": 150, "serum_cholesterol": 268, "fasting_blood_sugar": 1,
                "resting_electrocardiographic_results": 2, "maximum_heart_rate_achieved": 112, "exercise_induced_angina": 1, "oldpeak": 2.6,
                "slope": 2, "number_of_major_vessels": 2, "thal": 7},
}


@app.route("/assessment", methods=["GET", "POST"])
@login_required
def assessment():
    form, errors = {}, {}
    if request.method == "POST":
        form = request.form.to_dict()
        x, errors = parse_assessment(request.form)
        if not errors:
            result = predict(x)
            created = datetime.now().strftime("%d %b %Y · %I:%M %p")
            if result.get("ready"):
                details = {k: result[k] for k in ("catboost_probability", "ann_probability", "threshold", "threshold_pct", "catboost_weight",
                                                  "ann_weight", "level", "level_label", "color", "factors", "demo", "class", "note")}
                mtype = "Demo scorer (not the trained model)" if result["demo"] else "CatBoost + ANN ensemble"
                params = (session["user_id"], json.dumps(x), result["prediction"], result["probability"], mtype, created,
                          json.dumps(details), result["level"], request.form.get("note", "").strip()[:200])
            else:
                params = (session["user_id"], json.dumps(x), result["message"], None, "not_configured", created, None, None,
                          request.form.get("note", "").strip()[:200])
            with db() as con:
                cur = con.execute("""INSERT INTO assessments(user_id,payload,prediction,probability,model_type,created_at,details,risk_level,note)
                                     VALUES(?,?,?,?,?,?,?,?,?)""", params)
                aid = cur.lastrowid
            session["latest_assessment_id"] = aid
            return redirect(url_for("results", aid=aid))
        flash("A few fields need attention. They are highlighted below.", "error")
    p = get_profile(session["user_id"])
    return render_template("assessment.html", form=form, errors=errors, profile=p, samples=SAMPLES, model_ready=model_status())


@app.route("/results/<int:aid>")
@login_required
def results(aid):
    with db() as con:
        row = con.execute("SELECT * FROM assessments WHERE id=? AND user_id=?", (aid, session["user_id"])).fetchone()
    if not row:
        flash("Assessment not found.", "error")
        return redirect(url_for("reports"))
    a = row_to_assessment(row)
    others = [x for x in user_assessments(session["user_id"]) if x["id"] < aid]
    prev = others[0] if others else None
    delta = round(a["probability"] - prev["probability"], 1) if (prev and a["scored"] and prev["scored"]) else None
    p = get_profile(session["user_id"])
    plan = wellness.build_plan(p, a["payload"], a["level"])
    review = wellness.input_review(a["payload"])
    return render_template("results.html", a=a, d=a["details"], payload=a["payload"], review=review,
                           counts=wellness.count_tones(review), plan=plan, prev=prev, delta=delta,
                           notes=range_notes(a["payload"]), can_whatif=model_status() != "missing" and a["details"] is not None,
                           profile=p)


@app.route("/results")
@login_required
def latest_results():
    aid = session.get("latest_assessment_id")
    if not aid:
        return redirect(url_for("assessment"))
    return redirect(url_for("results", aid=aid))


@app.route("/api/predict", methods=["POST"])
@login_required
def api_predict():
    data = request.get_json(silent=True) or {}
    x, errors = parse_assessment({k: str(v) for k, v in data.items()})
    if errors:
        return jsonify(error="Invalid input", fields=errors), 400
    r = predict(x, explain=False)
    if not r.get("ready"):
        return jsonify(error=r["message"]), 503
    return jsonify({k: r[k] for k in ("probability", "threshold_pct", "level", "level_label", "color", "catboost_probability", "ann_probability", "demo")})


@app.route("/assessment/<int:aid>/delete", methods=["POST"])
@login_required
def delete_assessment(aid):
    with db() as con:
        con.execute("DELETE FROM assessments WHERE id=? AND user_id=?", (aid, session["user_id"]))
    flash("Assessment deleted.", "info")
    return redirect(url_for("reports"))

# ------------------------------------------------------------------ wellness plan

@app.route("/plan")
@login_required
def recommendations():
    p = get_profile(session["user_id"])
    a = user_assessments(session["user_id"], 1)
    latest = a[0] if a else None
    try:
        shuffle = max(0, min(50, int(request.args.get("s", 0))))
    except ValueError:
        shuffle = 0
    plan = wellness.build_plan(p, latest["payload"] if latest else None, latest["level"] if latest else None, shuffle)
    return render_template("recommendations.html", plan=plan, p=p, latest=latest, shuffle=shuffle)

# ------------------------------------------------------------------ tracker

@app.route("/tracker", methods=["GET", "POST"])
@login_required
def tracker():
    uid = session["user_id"]
    if request.method == "POST":
        def f(name, lo, hi):
            try:
                v = float(request.form.get(name) or "")
                return v if lo <= v <= hi else None
            except ValueError:
                return None
        s, d, pulse = f("systolic", 60, 260), f("diastolic", 30, 160), f("pulse", 30, 220)
        wt, gl = f("weight", 25, 300), f("glucose", 30, 600)
        if all(v is None for v in (s, d, pulse, wt, gl)):
            flash("Enter at least one valid reading.", "error")
        elif (s is None) != (d is None):
            flash("Enter both systolic and diastolic values for blood pressure.", "error")
        else:
            with db() as con:
                con.execute("INSERT INTO vitals(user_id,logged_at,systolic,diastolic,pulse,weight,glucose,note) VALUES(?,?,?,?,?,?,?,?)",
                            (uid, datetime.now().isoformat(timespec="minutes"), s, d, pulse, wt, gl, request.form.get("note", "").strip()[:200]))
            flash("Reading saved.", "success")
        return redirect(url_for("tracker"))
    vitals = user_vitals(uid, 60)
    series = list(reversed(vitals))
    return render_template("tracker.html", vitals=vitals, series=series)


@app.route("/tracker/<int:vid>/delete", methods=["POST"])
@login_required
def delete_vital(vid):
    with db() as con:
        con.execute("DELETE FROM vitals WHERE id=? AND user_id=?", (vid, session["user_id"]))
    flash("Reading removed.", "info")
    return redirect(url_for("tracker"))

# ------------------------------------------------------------------ reports

@app.route("/reports")
@login_required
def reports():
    rows = user_assessments(session["user_id"])
    trend = [{"label": a["short_date"], "p": a["probability"], "th": (a["details"] or {}).get("threshold_pct", 50), "id": a["id"]}
             for a in reversed(rows) if a["scored"]]
    return render_template("reports.html", rows=rows, trend=trend)


@app.route("/report/<int:aid>")
@login_required
def report(aid):
    with db() as con:
        row = con.execute("SELECT * FROM assessments WHERE id=? AND user_id=?", (aid, session["user_id"])).fetchone()
    if not row:
        flash("Report not found.", "error")
        return redirect(url_for("reports"))
    a = row_to_assessment(row)
    user = current_user()
    p = get_profile(user["id"])
    review = wellness.input_review(a["payload"])
    plan = wellness.build_plan(p, a["payload"], a["level"])
    return render_template("report_print.html", a=a, d=a["details"], payload=a["payload"], review=review, user=user,
                           plan=plan, notes=range_notes(a["payload"]), bmi=plan["bmi"], now=datetime.now().strftime("%d %b %Y"))


@app.route("/export.csv")
@login_required
def export_csv():
    rows = user_assessments(session["user_id"])
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["id", "date", "model_output", "probability_pct", "level", "threshold_pct", "catboost_pct", "ann_pct", "mode"] + list(FIELD_SPECS))
    for a in rows:
        d = a["details"] or {}
        w.writerow([a["id"], a["created_at"], a["prediction"], a["probability"], a["level_label"], d.get("threshold_pct"),
                    d.get("catboost_probability"), d.get("ann_probability"), a["mode"]] + [a["payload"].get(k) for k in FIELD_SPECS])
    return Response(buf.getvalue(), mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=cardiocare-assessments.csv"})

# ------------------------------------------------------------------ misc

@app.route("/health")
def health():
    return {"status": "ok", "app": "CardioCare AI", "model": model_status(), "model_ready": model_status() == "ready"}


@app.errorhandler(400)
def bad_request(_e):
    return render_template("error.html", code=400, title="That request didn't go through",
                           text="Your session may have expired. Go back, refresh the page and try again."), 400


@app.errorhandler(404)
def not_found(_e):
    return render_template("error.html", code=404, title="Page not found", text="The page you're looking for doesn't exist or was moved."), 404


if __name__ == "__main__":
    debug = os.environ.get("FLASK_DEBUG", "1") == "1"
    app.run(debug=debug)

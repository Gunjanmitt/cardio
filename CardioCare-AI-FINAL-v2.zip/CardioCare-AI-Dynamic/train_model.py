# CardioCare training pipeline adapted from the supplied Cleveland notebook.
import os, warnings, json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import norm
from ucimlrepo import fetch_ucirepo
from catboost import CatBoostClassifier
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import roc_auc_score, f1_score, accuracy_score
import joblib
warnings.filterwarnings("ignore")
SEED=42
N_SPLITS=5
BASE_FEATURES=["age","sex","cp","trestbps","chol","fbs","restecg","thalach","exang","oldpeak","slope","ca","thal"]
NUMERIC_BASE=["age","trestbps","chol","thalach","oldpeak"]
CATEGORICAL_BASE=["sex","cp","fbs","restecg","exang","slope","ca","thal"]
ENGINEERED_NUMERIC=["thalach_age_ratio","chol_age_ratio","trestbps_age_ratio","oldpeak_thalach_ratio","age_oldpeak","age_thalach","cp_oldpeak","exang_oldpeak","high_oldpeak","high_trestbps","high_chol","low_thalach"]
CATBOOST_FEATURES=NUMERIC_BASE+CATEGORICAL_BASE+ENGINEERED_NUMERIC
OUTPUT_DIR=str(Path(__file__).parent/"models")
os.makedirs(OUTPUT_DIR,exist_ok=True)


def load_local_cleveland():
    """Offline fallback. Put the UCI file `processed.cleveland.data` (no header, '?' = missing) in ./data,
    or a CSV with the 13 feature columns plus `num` (0 = no disease, 1-4 = disease)."""
    data_dir = Path(__file__).parent / "data"
    raw = data_dir / "processed.cleveland.data"
    if raw.exists():
        df = pd.read_csv(raw, header=None, names=BASE_FEATURES + ["num"], na_values="?")
    else:
        csvs = sorted(data_dir.glob("*.csv")) if data_dir.exists() else []
        if not csvs:
            raise SystemExit("No dataset found. Connect to the internet once, or download "
                             "https://archive.ics.uci.edu/ml/machine-learning-databases/heart-disease/processed.cleveland.data "
                             "into a folder named 'data' next to train_model.py.")
        df = pd.read_csv(csvs[0], na_values="?")
        df.columns = [str(c).strip().lower().replace(" ", "_") for c in df.columns]
        missing = [c for c in BASE_FEATURES + ["num"] if c not in df.columns]
        if missing:
            raise SystemExit(f"{csvs[0].name} is missing columns: {missing}")
    print(f"Using local dataset with {len(df)} rows.")
    return df[BASE_FEATURES].copy(), df["num"].copy()


def load_data():

    try:
        heart = fetch_ucirepo(id=45)          # UCI "Heart Disease" (Cleveland subset used here), downloaded once
        X = heart.data.features.copy()
        y = heart.data.targets.iloc[:, 0].copy()
        X.columns = [
            str(c).strip().lower().replace(" ", "_")
            for c in X.columns
        ]
    except Exception as exc:
        print(f"Could not download the dataset ({exc}). Looking for a local copy in ./data ...")
        X, y = load_local_cleveland()

    X = X[BASE_FEATURES].copy()

    # Convert missing-value markers to NaN.
    X = X.replace("?", np.nan)

    for col in NUMERIC_BASE:
        X[col] = pd.to_numeric(
            X[col],
            errors="coerce"
        )

    for col in CATEGORICAL_BASE:
        X[col] = X[col].where(
            X[col].notna(),
            np.nan
        ).astype("object")

    # Original target: 0 = no disease, 1-4 = disease.
    y = (
        pd.to_numeric(y, errors="coerce") > 0
    ).astype(int)

    return (
        X.reset_index(drop=True),
        y.reset_index(drop=True)
    )


# ============================================================
# 2. MISSING-VALUE IMPUTATION
# ============================================================

def fit_imputer_transform(train_raw, other_raw):
    """
    Fit imputation values on training rows only.
    Apply the same values to validation/test rows.
    """

    train = train_raw.copy()
    other = other_raw.copy()

    for col in NUMERIC_BASE:

        median_value = train[col].median()

        if pd.isna(median_value):
            median_value = 0.0

        train[col] = train[col].fillna(
            median_value
        ).astype(float)

        other[col] = other[col].fillna(
            median_value
        ).astype(float)

    for col in CATEGORICAL_BASE:

        mode_value = train[col].mode(
            dropna=True
        )

        if len(mode_value):
            fill_value = str(mode_value.iloc[0])
        else:
            fill_value = "unknown"

        train[col] = train[col].fillna(
            fill_value
        ).astype(str)

        other[col] = other[col].fillna(
            fill_value
        ).astype(str)

    return (
        train[BASE_FEATURES],
        other[BASE_FEATURES]
    )


# ============================================================
# 3. SYNTHETIC DATA GENERATION
# ============================================================

def empirical_quantile_sample(values, u):

    values = np.asarray(values, dtype=float)

    values = values[np.isfinite(values)]

    if len(values) == 0:
        return np.zeros(len(u))

    values = np.sort(values)

    positions = np.linspace(
        0, 1, len(values)
    )

    return np.interp(
        u,
        positions,
        values
    )


def generate_synthetic_class(
    X_class,
    n_samples,
    seed
):
    """
    Generate synthetic records using:
    - Correlation-based numerical sampling
    - Class-specific categorical sampling

    This is not a GAN-based method.
    """

    rng = np.random.default_rng(seed)

    X_class = X_class[BASE_FEATURES].copy()

    num_data = X_class[
        NUMERIC_BASE
    ].astype(float).to_numpy()

    ranks = np.zeros_like(
        num_data,
        dtype=float
    )

    for j in range(num_data.shape[1]):

        order = np.argsort(
            np.argsort(
                num_data[:, j],
                kind="mergesort"
            ),
            kind="mergesort"
        )

        ranks[:, j] = (
            (order + 1) / (len(num_data) + 1)
        )

    z = norm.ppf(
        np.clip(ranks, 0.001, 0.999)
    )

    corr = np.corrcoef(
        z,
        rowvar=False
    )

    corr = np.nan_to_num(
        corr,
        nan=0.0,
        posinf=0.0,
        neginf=0.0
    )

    corr = (
        0.90 * corr
        + 0.10 * np.eye(corr.shape[0])
    )

    eigvals, eigvecs = np.linalg.eigh(corr)

    corr = (
        eigvecs
        @ np.diag(np.maximum(eigvals, 1e-5))
        @ eigvecs.T
    )

    corr = (corr + corr.T) / 2

    z_new = rng.multivariate_normal(
        np.zeros(len(NUMERIC_BASE)),
        corr,
        size=n_samples
    )

    u_new = norm.cdf(z_new)

    synthetic = pd.DataFrame(
        index=range(n_samples)
    )

    # Generate numerical features.
    for j, col in enumerate(NUMERIC_BASE):

        vals = (
            X_class[col]
            .astype(float)
            .to_numpy()
        )

        generated = empirical_quantile_sample(
            vals,
            u_new[:, j]
        )

        noise = rng.normal(
            0,
            0.025 * max(np.std(vals), 1e-6),
            size=n_samples
        )

        synthetic[col] = generated + noise

    # Generate categorical features from class-specific
    # empirical category frequencies.
    for col in CATEGORICAL_BASE:

        vals = (
            X_class[col]
            .astype(str)
            .to_numpy()
        )

        categories, counts = np.unique(
            vals,
            return_counts=True
        )

        probabilities = counts / counts.sum()

        synthetic[col] = rng.choice(
            categories,
            size=n_samples,
            p=probabilities
        )

    # Keep numerical values within plausible dataset ranges.
    bounds = {
        "age": (20, 90),
        "trestbps": (80, 220),
        "chol": (100, 600),
        "thalach": (60, 220),
        "oldpeak": (0, 7)
    }

    for col, (lower, upper) in bounds.items():

        synthetic[col] = synthetic[col].clip(
            lower,
            upper
        )

    return synthetic[BASE_FEATURES]


def augment_training_data(
    X_real,
    y_real,
    seed
):
    """
    Add 500 synthetic samples for each target class.
    Only training-fold data is used to generate them.
    """

    y_array = np.asarray(
        y_real,
        dtype=int
    )

    X0 = X_real.loc[y_array == 0]
    X1 = X_real.loc[y_array == 1]

    syn0 = generate_synthetic_class(
        X0,
        500,
        seed + 100
    )

    syn1 = generate_synthetic_class(
        X1,
        500,
        seed + 200
    )

    X_syn = pd.concat(
        [syn0, syn1],
        ignore_index=True
    )

    y_syn = np.concatenate([
        np.zeros(len(syn0), dtype=int),
        np.ones(len(syn1), dtype=int)
    ])

    X_aug = pd.concat(
        [
            X_real.reset_index(drop=True),
            X_syn
        ],
        ignore_index=True
    )

    y_aug = np.concatenate([
        y_array,
        y_syn
    ])

    return (
        X_aug,
        y_aug,
        len(syn0),
        len(syn1)
    )


# ============================================================
# 4. FEATURE ENGINEERING
# ============================================================

def add_features(df):

    df = df.copy()

    for col in NUMERIC_BASE:

        df[col] = pd.to_numeric(
            df[col],
            errors="coerce"
        )

    df["thalach_age_ratio"] = (
        df["thalach"] / (df["age"] + 1e-5)
    )

    df["chol_age_ratio"] = (
        df["chol"] / (df["age"] + 1e-5)
    )

    df["trestbps_age_ratio"] = (
        df["trestbps"] / (df["age"] + 1e-5)
    )

    df["oldpeak_thalach_ratio"] = (
        df["oldpeak"] / (df["thalach"] + 1e-5)
    )

    df["age_oldpeak"] = (
        df["age"] * df["oldpeak"]
    )

    df["age_thalach"] = (
        df["age"] * df["thalach"]
    )

    df["cp_oldpeak"] = (
        pd.to_numeric(
            df["cp"],
            errors="coerce"
        ).fillna(0)
        * df["oldpeak"]
    )

    df["exang_oldpeak"] = (
        pd.to_numeric(
            df["exang"],
            errors="coerce"
        ).fillna(0)
        * df["oldpeak"]
    )

    df["high_oldpeak"] = (
        df["oldpeak"] > 1.0
    ).astype(int)

    df["high_trestbps"] = (
        df["trestbps"] >= 140
    ).astype(int)

    df["high_chol"] = (
        df["chol"] >= 240
    ).astype(int)

    df["low_thalach"] = (
        df["thalach"] < 120
    ).astype(int)

    return df.replace(
        [np.inf, -np.inf],
        np.nan
    )


def clean_engineered(
    train_df,
    other_df
):
    """
    Impute derived features using training-fold
    statistics only.
    """

    train_df = train_df.copy()
    other_df = other_df.copy()

    for col in train_df.columns:

        if not pd.api.types.is_numeric_dtype(train_df[col]):

            mode_value = train_df[col].mode(
                dropna=True
            )

            if len(mode_value):
                fill_value = str(mode_value.iloc[0])
            else:
                fill_value = "unknown"

            train_df[col] = (
                train_df[col]
                .fillna(fill_value)
                .astype(str)
            )

            other_df[col] = (
                other_df[col]
                .fillna(fill_value)
                .astype(str)
            )

        else:

            median_value = train_df[col].median()

            if pd.isna(median_value):
                median_value = 0.0

            train_df[col] = train_df[col].fillna(
                median_value
            )

            other_df[col] = other_df[col].fillna(
                median_value
            )

    return train_df, other_df


def prepare_fold(
    train_raw,
    y_train,
    valid_raw,
    seed,
    augment=True
):
    """
    Prepare training and validation data.

    Validation rows remain real and are never used
    to generate synthetic training samples.
    """

    Xtr, Xva = fit_imputer_transform(
        train_raw,
        valid_raw
    )

    if augment:

        Xtr, ytr, _, _ = augment_training_data(
            Xtr,
            y_train,
            seed
        )

    else:

        ytr = np.asarray(
            y_train,
            dtype=int
        )

    Xtr = add_features(Xtr)
    Xva = add_features(Xva)

    Xtr, Xva = clean_engineered(
        Xtr,
        Xva
    )

    return (
        Xtr,
        np.asarray(ytr, dtype=int),
        Xva
    )


# ============================================================

def make_ann_preprocessor():
    try: enc=OneHotEncoder(handle_unknown="ignore", sparse_output=False)
    except TypeError: enc=OneHotEncoder(handle_unknown="ignore", sparse=False)
    return ColumnTransformer([("num",StandardScaler(),NUMERIC_BASE+ENGINEERED_NUMERIC),("cat",enc,CATEGORICAL_BASE)],remainder="drop")

def cat_features_for(df):
    return [df.columns.get_loc(c) for c in CATEGORICAL_BASE]

def make_cat_model(seed=42):
    return CatBoostClassifier(iterations=550,depth=6,learning_rate=0.04,l2_leaf_reg=4.0,
        loss_function="Logloss",eval_metric="AUC",verbose=False,random_seed=seed,
        allow_writing_files=False,thread_count=-1)

def make_ann(seed=42):
    return MLPClassifier(hidden_layer_sizes=(64,32),alpha=0.001,learning_rate_init=0.002,
        batch_size=32,activation="relu",solver="adam",max_iter=1000,
        early_stopping=True,validation_fraction=0.15,n_iter_no_change=50,random_state=seed)

def engineered_for_inference(raw):
    x=raw[BASE_FEATURES].copy()
    for c in NUMERIC_BASE: x[c]=pd.to_numeric(x[c],errors="coerce")
    for c in CATEGORICAL_BASE: x[c]=x[c].astype(str)
    x=add_features(x)
    for c in CATEGORICAL_BASE: x[c]=x[c].astype(str)
    return x

def main():
    np.random.seed(SEED)
    X,y=load_data()
    print(f"Loaded Cleveland dataset: {len(X)} records")
    # OOF probabilities on real training folds select the ensemble weight and threshold.
    Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=0.20,stratify=y,random_state=SEED)
    Xtr=Xtr.reset_index(drop=True); ytr=ytr.reset_index(drop=True)
    oof_cat=np.zeros(len(Xtr)); oof_ann=np.zeros(len(Xtr))
    cv=StratifiedKFold(n_splits=N_SPLITS,shuffle=True,random_state=SEED)
    for fold,(ti,vi) in enumerate(cv.split(Xtr,ytr),1):
        xa,ya,xv=prepare_fold(Xtr.iloc[ti],ytr.iloc[ti],Xtr.iloc[vi],SEED+fold,augment=True)
        cat=make_cat_model(SEED+fold)
        cat.fit(xa[CATBOOST_FEATURES],ya,cat_features=cat_features_for(xa[CATBOOST_FEATURES]))
        oof_cat[vi]=cat.predict_proba(xv[CATBOOST_FEATURES])[:,1]
        prep=make_ann_preprocessor(); atr=prep.fit_transform(xa); av=prep.transform(xv)
        ann=make_ann(SEED+100+fold); ann.fit(atr,ya)
        oof_ann[vi]=ann.predict_proba(av)[:,1]
        print(f"OOF fold {fold}/{N_SPLITS} complete")
    best=(float('-inf'),0.5)
    for w in np.linspace(0,1,101):
        p=w*oof_cat+(1-w)*oof_ann
        try: score=roc_auc_score(ytr,p)
        except ValueError: score=-1
        if score>best[0]: best=(score,float(w))
    weight=best[1]
    oof_mix=weight*oof_cat+(1-weight)*oof_ann
    thresholds=np.linspace(0.20,0.80,121)
    threshold=max(thresholds,key=lambda t:f1_score(ytr,(oof_mix>=t).astype(int),zero_division=0))
    print(f"OOF ensemble AUC={best[0]:.4f}; CatBoost weight={weight:.2f}; threshold={threshold:.3f}")
    # Refit preprocessing and both models using all available real records plus
    # synthetic training records generated only from those records.
    xfit,yfit,_=prepare_fold(X,y,X,SEED+999,augment=True)
    cat_final=make_cat_model(SEED+2000)
    cat_final.fit(xfit[CATBOOST_FEATURES],yfit,cat_features=cat_features_for(xfit[CATBOOST_FEATURES]))
    ann_pre=make_ann_preprocessor(); ann_x=ann_pre.fit_transform(xfit)
    ann_final=make_ann(SEED+2001); ann_final.fit(ann_x,yfit)
    # Holdout is reported as a descriptive check; OOF-derived weight/threshold are kept.
    # Fit separate models on the 80% training split for a fair held-out estimate.
    xh,yh,xv=prepare_fold(Xtr,ytr,Xte,SEED+3000,augment=True)
    cat_h=make_cat_model(SEED+3001); cat_h.fit(xh[CATBOOST_FEATURES],yh,cat_features=cat_features_for(xh[CATBOOST_FEATURES]))
    phc=cat_h.predict_proba(xv[CATBOOST_FEATURES])[:,1]
    prep_h=make_ann_preprocessor(); ah=prep_h.fit_transform(xh); av=prep_h.transform(xv)
    ann_h=make_ann(SEED+3002); ann_h.fit(ah,yh); pha=ann_h.predict_proba(av)[:,1]
    ph=weight*phc+(1-weight)*pha
    print(f"Held-out 20% accuracy at OOF threshold: {accuracy_score(yte,(ph>=threshold).astype(int)):.4f}; AUC: {roc_auc_score(yte,ph):.4f}")
    cat_final.save_model(os.path.join(OUTPUT_DIR,"catboost_model.cbm"))
    joblib.dump(ann_final,os.path.join(OUTPUT_DIR,"ann_model.joblib"))
    joblib.dump(ann_pre,os.path.join(OUTPUT_DIR,"ann_preprocessor.joblib"))
    joblib.dump({"catboost_weight":weight,"ann_weight":1-weight,"threshold":float(threshold),
        "features":BASE_FEATURES,"target":"Cleveland: 0=no disease, 1-4=disease",
        "oof_auc":float(best[0]),"holdout_auc":float(roc_auc_score(yte,ph)),
        "holdout_accuracy":float(accuracy_score(yte,(ph>=threshold).astype(int))),
        "warning":"Research prototype only; not clinically validated."},os.path.join(OUTPUT_DIR,"ensemble_config.joblib"))
    print("Saved model files in",OUTPUT_DIR)
    print("Training complete. These outputs are research/demo predictions, not medical diagnoses.")

if __name__=="__main__": main()

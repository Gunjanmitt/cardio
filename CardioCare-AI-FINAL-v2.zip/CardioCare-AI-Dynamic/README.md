# CardioCare AI - CatBoost + ANN heart-disease risk app (Cleveland dataset)

Flask + SQLite web app around your CatBoost + ANN ensemble. Same teal look as the first prototype, with a much
richer experience: guided assessment wizard, explainable results, diet and exercise plans with pictures,
vitals tracker, reports and CSV export.

## Quick start (Windows PowerShell)

```powershell
cd CardioCare-AI-Dynamic
py -3 -m venv venv
.\venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python train_model.py        # needs internet once (downloads UCI Cleveland data), a few minutes
python app.py                # open http://127.0.0.1:5000
```

If PowerShell blocks activation: `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`

### Preview the UI before training

```powershell
python app.py --demo         # placeholder scorer, clearly labelled "Demo scorer" on every screen
python seed_demo.py --demo   # optional: creates demo@cardiocare.app / Demo@12345 with 6 assessments + 14 days of vitals
```
The demo scorer is NOT your model. Once `train_model.py` has run, the app automatically uses the trained ensemble.
Run `python seed_demo.py` (without `--demo`) to rebuild the demo history with real model output.

## What is in the app

| Page | What it does |
|---|---|
| Landing `/` | Public intro, features, how it works, FAQ |
| Dashboard | Bento layout: 3D beating heart, latest output dial, BMI/BP/pulse/weight with sparklines, trend chart, today's meals with pictures |
| New assessment | 4-step wizard, sliders + live range checks, sample patients, server-side validation |
| Result | Compact landscape page: verdict ring, CatBoost vs ANN numbers, SHAP "what pushed the output" chips, 13-input review, and a food/movement/limit section with pictures that changes when a pattern is flagged |
| Wellness plan | Calorie estimate, 7-day meal plan (diet + allergy filtering), exercise plan, breathing guide, food guide |
| Vitals tracker | Log BP, pulse, weight, glucose; charts and history |
| Reports | History, trend chart, filters, CSV export, printable report (Save as PDF) |
| About the model | Pipeline, your real metrics (after training), limitations |
| Profile | Height, weight, diet, allergies, activity, live BMI, delete-my-data |

## Fixes made to the original code

1. **Categorical mismatch (accuracy bug).** Training stores `ca` and `thal` as text like `"2.0"`; the old inference
   sent `"2"`, which CatBoost treats as an unseen category. `model_inference.py` now maps values to the exact training format.
2. **CatBoost column order** is now passed exactly as in training.
3. **pandas 3 crash in `train_model.py`.** `dtype == "object"` no longer matches string columns on pandas 3,
   which made training fail with "Cannot perform reduction 'median' with string dtype". Now uses `is_numeric_dtype`.
4. Dashboard/report "Model pending" labels never matched the saved model name, and cholesterol/BP warnings read the wrong keys. Both fixed.
5. CSRF protection on every POST, login throttling, random persisted secret key, security headers, input range validation.
6. Database migrates automatically from the first prototype (old assessments still open).
7. Fonts, icons and Chart.js are bundled locally in `static/vendor`, so the app works offline.

## Notes and limitations

- Research/education software. Not a medical device, not clinically validated, not for diagnosis or treatment.
- The Cleveland dataset is small (about 300 patients). Reported accuracy comes from your own `train_model.py` output; the
  numbers shown on "About the model" are read from the saved `ensemble_config.joblib`.
- SHAP bars describe how the CatBoost model reached its output, not causes in a person's body.
- Diet/exercise content is general guidance and is not individual medical or dietetic advice.
- Set a strong `SECRET_KEY` environment variable and use a production server (gunicorn/waitress) before any real deployment.

## Training data (Cleveland)

`python train_model.py` trains **CatBoost and an ANN (scikit-learn MLP) on the UCI Cleveland heart-disease data**
(303 patients, 13 features; target 0 = no disease, 1-4 = disease, converted to binary). It downloads the data once via
`ucimlrepo`. If the download fails, put the UCI file `processed.cleveland.data` (or a CSV with the 13 columns plus `num`)
in a folder named `data/` next to `train_model.py` and run it again, it will use that automatically.
Training uses 5-fold out-of-fold predictions to choose the CatBoost/ANN blend weight and the F1 threshold, keeps a 20% held-out
test split for reporting, then saves the models into `models/`. Synthetic augmentation is applied to training folds only.

## 3D heart and meal pictures

- The dashboard and landing page show a real-time 3D heart (Three.js, bundled in `static/vendor`). It beats at your latest logged pulse
  (default 72 bpm) and the ECG line is synced to it. Without WebGL it falls back to the static heart image.
- Meal cards use illustrated dish pictures generated in `dish_art.py` (offline, no external images). The food and exercise
  photo cards use Unsplash links in `wellness.py` (`PHOTO_FOODS`); replace a link there if you want a different photo.

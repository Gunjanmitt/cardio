"""Educational wellness engine for CardioCare AI.

Everything here is general, guideline-style education (DASH / Mediterranean-style eating, AHA-style
activity ranges). It does not diagnose, prescribe or replace a clinician or registered dietitian.
"""
import re
from datetime import date

DISCLAIMER = ("Educational suggestions only. They are not a prescribed diet or exercise programme. "
              "Ask your clinician or a registered dietitian before changing food, fluids, medication or activity.")

# ----------------------------------------------------------------------------------------------
# Body metrics
# ----------------------------------------------------------------------------------------------

def bmi_info(height_cm, weight_kg):
    try:
        h, w = float(height_cm) / 100.0, float(weight_kg)
        if h <= 0.5 or w <= 10:
            return None
    except (TypeError, ValueError):
        return None
    bmi = w / (h * h)
    if bmi < 18.5:
        cat, tone = "Below typical range", "watch"
    elif bmi < 25:
        cat, tone = "Typical range", "ok"
    elif bmi < 30:
        cat, tone = "Above typical range", "watch"
    else:
        cat, tone = "Well above typical range", "flag"
    return {"value": round(bmi, 1), "category": cat, "tone": tone,
            "note": "Some guidelines use lower cut-offs (about 23 and 27.5) for South Asian adults."}


def bp_category(sys_, dia):
    """AHA-style blood-pressure categories for display."""
    try:
        s, d = float(sys_), float(dia)
    except (TypeError, ValueError):
        return {"label": "Not recorded", "tone": "info"}
    if s > 180 or d > 120:
        return {"label": "Very high - seek medical advice", "tone": "flag"}
    if s >= 140 or d >= 90:
        return {"label": "High (stage 2 range)", "tone": "flag"}
    if s >= 130 or d >= 80:
        return {"label": "High (stage 1 range)", "tone": "watch"}
    if s >= 120:
        return {"label": "Elevated", "tone": "watch"}
    return {"label": "Typical", "tone": "ok"}


def daily_energy(profile, payload):
    """Mifflin-St Jeor estimate. Needs height, weight, age and sex."""
    try:
        h, w = float(profile.get("height")), float(profile.get("weight"))
        age, sex = float(payload.get("age")), int(payload.get("sex"))
    except (TypeError, ValueError, AttributeError):
        return None
    bmr = 10 * w + 6.25 * h - 5 * age + (5 if sex == 1 else -161)
    factor = {"sedentary": 1.2, "light": 1.375, "moderate": 1.55, "active": 1.725}.get(profile.get("activity", "light"), 1.375)
    tdee = bmr * factor
    bmi = w / ((h / 100) ** 2)
    target, why = tdee, "to maintain your weight"
    if bmi >= 25:
        target, why = tdee * 0.90, "a gentle ~10% reduction because your BMI is above the typical range"
    elif bmi < 18.5:
        target, why = tdee * 1.10, "a gentle ~10% increase because your BMI is below the typical range"
    floor = 1500 if sex == 1 else 1200
    target = max(floor, round(target / 50) * 50)
    return {"kcal": int(target), "maintenance": int(round(tdee / 50) * 50), "why": why}

# ----------------------------------------------------------------------------------------------
# Meal library  (level: 0 vegan, 1 vegetarian, 2 + egg, 3 + meat/fish)
# ----------------------------------------------------------------------------------------------
# (level, name, short description, ingredient keywords used for allergy filtering)
MEALS = {
 "breakfast": [
  (0, "Vegetable oats upma", "Fibre-rich oats with peas, carrot and curry leaves.", ("oats", "peas", "carrot", "mustard")),
  (0, "Ragi porridge with banana", "Finger-millet porridge, cinnamon, sliced banana.", ("ragi", "banana", "cinnamon")),
  (0, "Poha with peas and a few peanuts", "Light flattened-rice bowl, lemon, minimal oil.", ("rice", "peas", "peanut", "lemon")),
  (0, "Moong dal chilla with mint chutney", "Protein-rich lentil pancakes with onion and herbs.", ("moong", "lentil", "mint", "onion")),
  (0, "Overnight oats with berries and chia", "Oats soaked in unsweetened almond milk, berries, chia.", ("oats", "berries", "chia", "almond")),
  (0, "Idli with vegetable sambar", "Steamed rice-lentil cakes with a vegetable lentil stew.", ("rice", "urad", "lentil", "vegetables")),
  (0, "Whole-grain toast with hummus and tomato", "Wholemeal bread, chickpea hummus, cucumber, tomato.", ("wheat", "bread", "chickpea", "sesame", "tomato")),
  (1, "Yoghurt bowl with fruit and flaxseed", "Plain low-fat yoghurt, seasonal fruit, ground flaxseed.", ("yogurt", "milk", "dairy", "fruit", "flaxseed")),
  (1, "Paneer-vegetable whole-wheat wrap", "Grilled paneer, crunchy vegetables, whole-wheat roti.", ("paneer", "milk", "dairy", "wheat", "vegetables")),
  (2, "Vegetable omelette with wholegrain toast", "Two-egg omelette packed with vegetables.", ("egg", "vegetables", "wheat", "bread")),
  (2, "Boiled eggs with sprouts salad", "One or two eggs with moong sprouts, lemon, pepper.", ("egg", "sprouts", "lemon")),
  (3, "Chicken-and-salad wholegrain sandwich", "Grilled skinless chicken, lettuce, cucumber.", ("chicken", "wheat", "bread", "lettuce")),
 ],
 "snack": [
  (0, "Seasonal fruit", "An apple, guava, orange or papaya.", ("fruit",)),
  (0, "Roasted chana", "Dry-roasted chickpeas, no added salt.", ("chickpea",)),
  (0, "Small handful of unsalted nuts", "Walnuts or almonds (about 20-30 g).", ("walnut", "almond", "nuts")),
  (0, "Cucumber and carrot sticks with hummus", "Crunchy raw vegetables, chickpea dip.", ("cucumber", "carrot", "chickpea", "sesame")),
  (0, "Sprouts chaat, no added salt", "Moong sprouts, onion, tomato, lemon.", ("sprouts", "onion", "tomato", "lemon")),
  (0, "Roasted makhana", "Dry-roasted fox nuts with black pepper.", ("makhana",)),
  (1, "Low-salt buttermilk", "Diluted curd drink with roasted cumin.", ("buttermilk", "milk", "dairy", "yogurt")),
 ],
 "lunch": [
  (0, "Dal, brown rice and mixed sabzi", "Lentils, brown rice and two vegetables, cooked with little oil.", ("lentil", "rice", "vegetables")),
  (0, "Rajma with jowar roti and cucumber salad", "Kidney beans, sorghum flatbread, raw salad.", ("kidney beans", "sorghum", "cucumber")),
  (0, "Chana-vegetable curry with millet roti", "Chickpea curry, seasonal vegetables, millet roti.", ("chickpea", "vegetables", "millet")),
  (0, "Quinoa-vegetable bowl with lemon-tahini", "Quinoa, roasted vegetables, light tahini dressing.", ("quinoa", "vegetables", "sesame", "lemon")),
  (0, "Sambar rice with beetroot poriyal", "Vegetable lentil stew over rice, beetroot side.", ("lentil", "rice", "beetroot", "vegetables")),
  (0, "Lentil soup, whole-wheat roti and salad", "Warm soup, one roti, big leafy salad.", ("lentil", "wheat", "vegetables")),
  (0, "Bean-and-avocado burrito bowl", "Black beans, brown rice, salsa, avocado.", ("beans", "rice", "avocado", "tomato")),
  (1, "Light palak paneer with whole-wheat roti", "Spinach gravy, small paneer portion, one or two rotis.", ("spinach", "paneer", "milk", "dairy", "wheat")),
  (1, "Moong khichdi with vegetable raita", "One-pot rice-lentil comfort meal with a cooling side.", ("rice", "moong", "lentil", "yogurt", "dairy", "milk")),
  (2, "Egg curry (light gravy) with brown rice", "Tomato-onion gravy, brown rice, cucumber salad.", ("egg", "tomato", "onion", "rice")),
  (3, "Grilled fish with sauteed vegetables and brown rice", "Baked or grilled fish, plenty of vegetables.", ("fish", "vegetables", "rice")),
  (3, "Chicken-vegetable stir-fry with brown rice", "Skinless chicken, mixed vegetables, little oil.", ("chicken", "vegetables", "rice")),
  (3, "Tandoori-style chicken, dal and salad", "Oven-grilled chicken, a small bowl of dal, salad.", ("chicken", "lentil", "vegetables", "yogurt", "dairy")),
 ],
 "evening": [
  (0, "Green tea with roasted seeds", "Unsweetened tea, pumpkin and sunflower seeds.", ("tea", "seeds", "pumpkin", "sunflower")),
  (0, "Clear vegetable soup", "Low-salt broth with beans, carrot and greens.", ("vegetables", "beans", "carrot")),
  (0, "Sweet-potato chaat", "Boiled sweet potato, lemon, chaat spices.", ("sweet potato", "lemon")),
  (0, "Avocado on wholegrain toast", "Mashed avocado, chilli flakes, lemon.", ("avocado", "wheat", "bread", "lemon")),
  (0, "Corn and vegetable salad", "Sweet corn, cucumber, tomato, herbs.", ("corn", "cucumber", "tomato")),
  (1, "Plain yoghurt with berries", "Unsweetened yoghurt and a few berries.", ("yogurt", "milk", "dairy", "berries")),
 ],
 "dinner": [
  (0, "Vegetable khichdi with moong dal", "Light one-pot dinner, plenty of vegetables.", ("rice", "moong", "lentil", "vegetables")),
  (0, "Besan-vegetable cheela with salad", "Chickpea-flour pancakes stuffed with vegetables.", ("chickpea", "besan", "vegetables")),
  (0, "Tofu-vegetable stir-fry with brown rice", "Tofu, broccoli, peppers, light soy-free seasoning option.", ("tofu", "soy", "vegetables", "rice")),
  (0, "Lauki-chana dal with one or two rotis", "Bottle gourd and split chickpea dal.", ("bottle gourd", "chickpea", "lentil", "wheat")),
  (0, "Vegetable soup with multigrain toast", "Thick vegetable soup, one slice of multigrain toast.", ("vegetables", "wheat", "bread")),
  (0, "Roasted vegetables with quinoa", "Oven-roasted vegetables over quinoa, lemon dressing.", ("vegetables", "quinoa", "lemon")),
  (1, "Vegetable dalia with curd", "Broken-wheat porridge, vegetables, small bowl of curd.", ("wheat", "vegetables", "yogurt", "milk", "dairy")),
  (1, "Paneer-capsicum bhurji with roti", "Crumbled paneer with vegetables, one roti.", ("paneer", "milk", "dairy", "wheat")),
  (2, "Egg-white bhurji with vegetables and roti", "Soft egg-white scramble, vegetables, one roti.", ("egg", "vegetables", "wheat")),
  (3, "Baked salmon with steamed greens", "Omega-3-rich fish with leafy greens and potato.", ("salmon", "fish", "vegetables", "potato")),
  (3, "Chicken-vegetable soup with toast", "Broth-based soup, shredded chicken, one toast.", ("chicken", "vegetables", "wheat", "bread")),
  (3, "Grilled fish tikka with vegetable salad", "Spiced grilled fish, raw salad, lemon.", ("fish", "yogurt", "dairy", "vegetables", "lemon")),
 ],
}

SLOT_LAYOUT = {
    2: [("lunch", "Lunch", .50), ("dinner", "Dinner", .50)],
    3: [("breakfast", "Breakfast", .27), ("lunch", "Lunch", .38), ("dinner", "Dinner", .35)],
    4: [("breakfast", "Breakfast", .25), ("lunch", "Lunch", .33), ("evening", "Evening snack", .12), ("dinner", "Dinner", .30)],
    5: [("breakfast", "Breakfast", .22), ("snack", "Mid-morning", .10), ("lunch", "Lunch", .30), ("evening", "Evening snack", .10), ("dinner", "Dinner", .28)],
}
SLOT_ICON = {"breakfast": "ti-sun", "snack": "ti-apple", "lunch": "ti-soup", "evening": "ti-cup", "dinner": "ti-moon"}
DIET_LEVEL = {"vegan": 0, "vegetarian": 1, "eggetarian": 2, "non-vegetarian": 3}

ALLERGY_ALIASES = {
    "nut": ["almond", "walnut", "cashew", "pistachio", "hazelnut", "peanut", "nuts"],
    "peanut": ["peanut"], "groundnut": ["peanut"],
    "dairy": ["milk", "yogurt", "paneer", "cheese", "ghee", "butter", "dairy", "buttermilk"],
    "lactose": ["milk", "yogurt", "paneer", "cheese", "dairy", "buttermilk"], "milk": ["milk", "yogurt", "paneer", "cheese", "dairy", "buttermilk"],
    "gluten": ["wheat", "bread", "oats", "barley", "semolina"], "wheat": ["wheat", "bread"],
    "egg": ["egg"], "soy": ["soy", "tofu"], "fish": ["fish", "salmon"],
    "shellfish": ["prawn", "shrimp", "crab"], "sesame": ["sesame", "tahini"],
}


def _forbidden_terms(allergy_text):
    terms = set()
    for raw in re.split(r"[,;/\n]| and ", (allergy_text or "").lower()):
        tok = raw.strip()
        if len(tok) < 3:
            continue
        terms.add(tok)
        for key, vals in ALLERGY_ALIASES.items():
            if key in tok or tok in key:
                terms.update(vals)
    return terms


def _eligible(slot, level, forbidden):
    out, removed = [], 0
    for lvl, name, desc, ing in MEALS[slot]:
        if lvl > level:
            continue
        if forbidden and any(f in i or i in f for f in forbidden for i in ing):
            removed += 1
            continue
        out.append({"name": name, "desc": desc, "level": lvl, "ing": ing})
    return out, removed


DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]


def meal_plan(profile, kcal, shuffle=0):
    diet = (profile or {}).get("diet", "vegetarian")
    level = DIET_LEVEL.get(diet, 1)
    forbidden = _forbidden_terms((profile or {}).get("allergies", ""))
    try:
        meals = int((profile or {}).get("meals", 3))
    except (TypeError, ValueError):
        meals = 3
    layout = SLOT_LAYOUT.get(meals, SLOT_LAYOUT[3])
    pools, removed_total, thin = {}, 0, []
    for slot, _, _ in layout:
        pool, removed = _eligible(slot, level, forbidden)
        removed_total += removed
        if len(pool) < 3:
            thin.append(slot)
        pools[slot] = pool
    week = []
    for d, day in enumerate(DAYS):
        items = []
        for s_i, (slot, label, share) in enumerate(layout):
            pool = pools[slot]
            if pool:
                m = pool[(d + s_i * 2 + shuffle) % len(pool)]
                entry = {"name": m["name"], "desc": m["desc"], "ing": m["ing"]}
            else:
                entry = {"name": "Build your own plate", "desc": "Your filters removed every sample option here. Ask a dietitian for a safe template."}
            entry.update({"slot": slot, "label": label, "icon": SLOT_ICON[slot],
                          "kcal": int(round(kcal * share / 10) * 10) if kcal else None})
            items.append(entry)
        week.append({"day": day, "short": day[:3], "meals": items})
    generic = {"vegetables", "fruit", "seeds", "tea", "nuts", "berries"}
    ing = sorted({i for dd in week for m in dd["meals"] for i in m.get("ing", ()) if i not in generic})
    return {"week": week, "ingredients": ing, "removed": removed_total, "thin_slots": thin, "meals_per_day": meals, "diet": diet}

# ----------------------------------------------------------------------------------------------
# Nutrition targets & food guidance
# ----------------------------------------------------------------------------------------------

EAT_MORE = [
    ("Vegetables and fruit", "Aim for half your plate; include leafy greens and a rainbow of colours.", "ti-carrot"),
    ("Whole grains and millets", "Oats, brown rice, ragi, jowar, bajra, whole-wheat roti.", "ti-grain"),
    ("Pulses, beans and lentils", "Dal, rajma, chana, sprouts - fibre and plant protein.", "ti-leaf"),
    ("Unsalted nuts and seeds", "A small handful a day, if you are not allergic.", "ti-seeding"),
    ("Oily fish or flax/chia", "Omega-3 sources, if they suit your diet.", "ti-fish"),
    ("Plain yoghurt or buttermilk", "Low-salt, unsweetened (if you eat dairy).", "ti-milk"),
]
LIMIT = [
    ("Added salt and salty snacks", "Pickles, papad, chips, instant noodles, processed meats.", "ti-salt"),
    ("Deep-fried foods", "Samosa, pakora, fries, bakery items made with trans or hydrogenated fat.", "ti-flame"),
    ("Sugary drinks and sweets", "Soft drinks, packaged juice, mithai, sweetened tea or coffee.", "ti-cup-off"),
    ("Refined flour products", "White bread, maida snacks, bakery biscuits.", "ti-bread-off"),
    ("Red and processed meat", "Keep portions small and occasional; choose skinless poultry or fish.", "ti-meat"),
    ("Excess ghee, butter and coconut oil", "Use small measured amounts; prefer mustard, olive or groundnut oil in moderation.", "ti-droplet-off"),
]
SWAPS = [
    ("White rice or maida roti", "Brown rice, millets or whole-wheat roti"),
    ("Fried snack", "Roasted chana, makhana or fruit"),
    ("Sweet tea / soft drink", "Unsweetened tea, lemon water or buttermilk"),
    ("Extra salt at the table", "Lemon, herbs, garlic, pepper, roasted cumin"),
    ("Butter spread", "Mashed avocado or hummus"),
]


def nutrition_targets(kcal, profile, payload, risk_level):
    conds = ((profile or {}).get("conditions") or "").lower()
    high_bp = False
    try:
        high_bp = float((payload or {}).get("resting_blood_pressure", 0)) >= 130
    except (TypeError, ValueError):
        pass
    low_salt = high_bp or risk_level in ("elevated", "high") or "pressure" in conds or "hypert" in conds
    t = {"sodium_mg": 1500 if low_salt else 2300,
         "sodium_note": "Lower sodium target suggested because of your entered values or health context."
                        if low_salt else "General upper limit for most adults.",
         "fibre": "25-35 g"}
    if kcal:
        t.update({"protein_g": int(kcal * .18 / 4), "carbs_g": int(kcal * .50 / 4), "fat_g": int(kcal * .30 / 9),
                  "sat_fat_g": int(kcal * .06 / 9)})
    try:
        w = float((profile or {}).get("weight"))
        t["water_l"] = round(min(3.0, max(1.5, w * 0.033)), 1)
    except (TypeError, ValueError):
        t["water_l"] = None
    return t


def food_warnings(profile, payload):
    w = []
    allergies = ((profile or {}).get("allergies") or "").strip()
    conds = ((profile or {}).get("conditions") or "").strip()
    if allergies:
        w.append(f"You listed allergies ({allergies}). We filter obvious ingredients, but every sample meal must still be checked for hidden ingredients and cross-contact. Nothing here is allergy-cleared.")
    if conds:
        w.append(f"You listed health context ({conds}). A clinician or registered dietitian should review portions, sodium, potassium, carbohydrate and medication interactions.")
        low = conds.lower()
        if any(k in low for k in ("kidney", "ckd", "renal")):
            w.append("With kidney conditions, potassium, phosphorus and fluid limits can be critical. Do not follow the generic water or high-potassium suggestions without your nephrologist's advice.")
        if "diabet" in low or "sugar" in low:
            w.append("With diabetes, carbohydrate portions and timing matter. Ask your care team to adapt the meal timings and quantities.")
        if any(k in low for k in ("warfarin", "blood thinner", "anticoag")):
            w.append("If you take warfarin, keep vitamin-K foods (leafy greens) consistent and check changes with your clinician.")
    try:
        if float((payload or {}).get("serum_cholesterol", 0)) >= 240:
            w.append("Your entered cholesterol is at or above a common 240 mg/dL cut-off. Discuss a full lipid profile with a clinician.")
        if float((payload or {}).get("resting_blood_pressure", 0)) >= 140:
            w.append("Your entered resting blood pressure is 140 mm Hg or higher. Repeat it correctly and discuss it with a clinician.")
    except (TypeError, ValueError):
        pass
    return w

# ----------------------------------------------------------------------------------------------
# Exercise
# ----------------------------------------------------------------------------------------------

BASE_MINUTES = {"sedentary": 12, "light": 20, "moderate": 30, "active": 40}
STOP_SIGNS = ["Chest pain, pressure or tightness", "Unusual breathlessness", "Dizziness, light-headedness or fainting",
              "Irregular or racing heartbeat", "Pain spreading to arm, jaw or back", "Cold sweat or nausea"]


def exercise_plan(profile, payload, risk_level):
    activity = (profile or {}).get("activity", "light")
    base = BASE_MINUTES.get(activity, 20)
    exang = str((payload or {}).get("exercise_induced_angina", "0")) == "1"
    cautious = risk_level in ("elevated", "high") or exang
    mode = "clinician_first" if cautious else ("careful" if risk_level == "moderate" else "standard")
    if mode == "clinician_first":
        base = min(base, 20)
    elif mode == "careful":
        base = min(base, 30)
    easy = "Easy: you can speak full sentences."
    mod = "Moderate: you can talk but not sing."
    plan = [
        ("Monday", "walk", "Brisk walk" if mode == "standard" else "Easy walk", base, easy if cautious else mod, "Walk on flat ground at a steady, comfortable pace.", "ti-walk"),
        ("Tuesday", "mobility", "Mobility and stretching", 15, "Gentle", "Neck, shoulder, hip and ankle circles; hold stretches 20-30 seconds.", "ti-yoga"),
        ("Wednesday", "walk", "Steady walk or light cycling" if mode != "clinician_first" else "Easy walk", base, easy if cautious else mod, "Keep effort steady; slow down if you cannot talk.", "ti-bike" if mode != "clinician_first" else "ti-walk"),
        ("Thursday", "breath", "Breathing and relaxation", 10, "Very gentle", "Slow breathing (try the guide below) and a short body scan.", "ti-wind"),
        ("Friday", "strength" if mode == "standard" else "walk", "Light strength circuit" if mode == "standard" else "Easy walk", 20 if mode == "standard" else min(base, 15),
         "Light" if mode == "standard" else easy, "Wall push-ups, chair squats, band rows - never hold your breath." if mode == "standard" else "Short, relaxed walk; rest if tired.", "ti-barbell" if mode == "standard" else "ti-walk"),
        ("Saturday", "walk", "Longer relaxed outing", int(base * 1.3) if mode == "standard" else base, easy if cautious else mod, "A park walk, easy cycle or gentle swim - pick something you enjoy.", "ti-trees"),
        ("Sunday", "rest", "Rest and recovery", 0, "Rest", "Light stretching, hydration and good sleep.", "ti-bed"),
    ]
    days = [{"day": d, "kind": k, "title": t, "minutes": m, "intensity": i, "desc": ds, "icon": ic} for d, k, t, m, i, ds, ic in plan]
    total = sum(d["minutes"] for d in days)
    hr = None
    try:
        age = float((payload or {}).get("age"))
        mx = 220 - age
        if mode != "clinician_first":
            hr = {"max": int(mx), "low": int(mx * .5), "high": int(mx * .7)}
    except (TypeError, ValueError):
        pass
    headline = {
        "clinician_first": "Clinician-first plan: keep everything easy until a doctor confirms what is safe for you.",
        "careful": "Careful build-up plan: gradual, steady movement with no sudden jumps in effort.",
        "standard": "Steady-build plan: mostly moderate activity with light strength twice a week at most.",
    }[mode]
    return {"mode": mode, "headline": headline, "days": days, "total_minutes": total, "hr": hr,
            "stop_signs": STOP_SIGNS, "guideline": "General adult guidance aims for about 150 minutes a week of moderate activity - only when it is safe for you."}

# ----------------------------------------------------------------------------------------------
# Input review (the 13 model inputs vs reference ranges)
# ----------------------------------------------------------------------------------------------
CP_TXT = {1: "Typical angina", 2: "Atypical angina", 3: "Non-anginal pain", 4: "Asymptomatic"}
ECG_TXT = {0: "Normal", 1: "ST-T wave abnormality", 2: "Left ventricular hypertrophy"}
SLOPE_TXT = {1: "Upsloping", 2: "Flat", 3: "Downsloping"}
THAL_TXT = {3: "Normal", 6: "Fixed defect", 7: "Reversible defect"}


def input_review(p):
    rows = []

    def add(label, value, tone, note, icon):
        rows.append({"label": label, "value": value, "tone": tone, "note": note, "icon": icon})

    age = float(p["age"])
    add("Age", f"{int(age)} years", "info", "Age is one of the strongest background factors in the dataset.", "ti-calendar")
    add("Sex", "Male" if int(p["sex"]) == 1 else "Female", "info", "Recorded as in the Cleveland dataset coding.", "ti-gender-bigender")
    cp = int(p["chest_pain_type"])
    add("Chest pain type", CP_TXT.get(cp, "-"), {1: "flag", 2: "watch", 3: "ok", 4: "watch"}.get(cp, "info"),
        {1: "Typical angina pattern.", 2: "Some features of angina.", 3: "Pain not usually linked to the heart.",
         4: "In the Cleveland data this category is common among positive cases; it does not mean you are symptom-free of risk."}.get(cp, ""), "ti-heart-broken")
    bp = float(p["resting_blood_pressure"])
    add("Resting blood pressure", f"{bp:g} mm Hg", "ok" if bp < 130 else ("watch" if bp < 140 else "flag"),
        "Under 130 is typical; 140 and above is high on a single reading." if bp >= 130 else "Within a typical range.", "ti-gauge")
    ch = float(p["serum_cholesterol"])
    add("Serum cholesterol", f"{ch:g} mg/dL", "ok" if ch < 200 else ("watch" if ch < 240 else "flag"),
        "Under 200 is desirable, 200-239 borderline, 240 and above high.", "ti-droplet")
    add("Fasting blood sugar", "Above 120 mg/dL" if int(p["fasting_blood_sugar"]) == 1 else "120 mg/dL or below",
        "watch" if int(p["fasting_blood_sugar"]) == 1 else "ok", "A fasting value above 120 mg/dL deserves a follow-up." if int(p["fasting_blood_sugar"]) == 1 else "Within the usual fasting range.", "ti-candy")
    ecg = int(p["resting_electrocardiographic_results"])
    add("Resting ECG", ECG_TXT.get(ecg, "-"), "ok" if ecg == 0 else "watch", "A normal resting ECG does not rule out disease." if ecg == 0 else "Abnormal resting ECG patterns are worth discussing.", "ti-activity-heartbeat")
    hr = float(p["maximum_heart_rate_achieved"])
    pct = hr / max(1.0, 220 - age) * 100
    add("Maximum heart rate", f"{hr:g} bpm ({pct:.0f}% of age estimate)", "ok" if pct >= 85 else ("info" if pct >= 70 else "watch"),
        "Compared with the rough 220-minus-age estimate. Medicines such as beta-blockers lower this.", "ti-heartbeat")
    ex = int(p["exercise_induced_angina"]) == 1
    add("Exercise-induced angina", "Yes" if ex else "No", "flag" if ex else "ok", "Chest pain brought on by exertion should be reviewed by a clinician." if ex else "No exertional chest pain reported.", "ti-run")
    op = float(p["oldpeak"])
    add("ST depression (oldpeak)", f"{op:g}", "ok" if op <= 1 else ("watch" if op <= 2 else "flag"), "ST depression induced by exercise relative to rest; larger values are more concerning.", "ti-chart-line")
    sl = int(p["slope"])
    add("Peak-exercise ST slope", SLOPE_TXT.get(sl, "-"), {1: "ok", 2: "watch", 3: "flag"}.get(sl, "info"), "Downsloping and flat patterns are weighed more heavily.", "ti-trending-up")
    ca = int(p["number_of_major_vessels"])
    add("Major vessels coloured", str(ca), "ok" if ca == 0 else ("watch" if ca == 1 else "flag"), "Number of major vessels (0-3) coloured by fluoroscopy.", "ti-git-branch")
    th = int(p["thal"])
    add("Thalassemia (stress test)", THAL_TXT.get(th, "-"), {3: "ok", 6: "watch", 7: "flag"}.get(th, "info"), "Result category from thallium stress imaging.", "ti-microscope")
    return rows


def count_tones(rows):
    c = {"ok": 0, "watch": 0, "flag": 0, "info": 0}
    for r in rows:
        c[r["tone"]] = c.get(r["tone"], 0) + 1
    return c


TIPS = [
    ("Salt less, flavour more", "Lemon, garlic, pepper, roasted cumin and herbs make low-salt food taste great."),
    ("Two-minute reset", "Stand up, roll your shoulders and take five slow breaths every hour at your desk."),
    ("Half-plate rule", "Fill half your plate with vegetables before you add anything else."),
    ("Read labels", "Look for sodium, added sugar and saturated fat per serving on packaged foods."),
    ("Sleep is cardio care", "Most adults do best with 7-9 hours; a regular bedtime helps blood pressure."),
    ("Measure BP properly", "Sit quietly for 5 minutes, feet flat, arm at heart level, no caffeine beforehand."),
    ("Walk after meals", "A relaxed 10-minute stroll after dinner is a gentle, sustainable habit."),
    ("Hydrate smartly", "Keep water within reach - unless your clinician has limited your fluids."),
]


def daily_tip():
    return TIPS[date.today().toordinal() % len(TIPS)]


# ----------------------------------------------------------------------------------------------
# Photo cards (from the original prototype)
# ----------------------------------------------------------------------------------------------
_U = "https://images.unsplash.com/photo-%s?auto=format&fit=crop&w=900&q=85"
PHOTO_FOODS = [  # (title, description, tag, image, kind, why)   kind: plant = fits every diet, all = not vegan, nonveg = non-vegetarian only
    ("Colourful vegetable bowl", "Build meals around seasonal vegetables, dal/beans and a whole grain.", "Everyday meal", _U % "1512621776951-a57141f2e-efd", "plant", "Fibre and plant variety are central to heart-healthy eating patterns."),
    ("Oats & fruit breakfast", "Unsweetened oats with fruit and a small portion of nuts or seeds, if suitable.", "Breakfast", _U % "1517673132405-a56a62b18caf", "all", "Oats are a source of soluble fibre, often suggested for cholesterol-friendly eating."),
    ("Grilled protein plate", "A balanced plate with a suitable protein, vegetables and whole grains.", "Lunch / dinner", _U % "1546069901-ba9599a7e63c", "all", "Lean protein with vegetables keeps saturated fat and salt low."),
    ("Lentil & millet meal", "A fibre-rich option using dal, millet or whole-wheat roti and vegetables.", "Indian meal idea", _U % "1547592180-85f173990554", "plant", "Pulses and millets add fibre and slow-release energy."),
    ("Baked fish with greens", "Oily fish such as salmon or mackerel, baked, with steamed leafy vegetables.", "Omega-3 idea", _U % "1467003909585-2f8a72700288", "nonveg", "Oily fish is a common omega-3 source in heart-healthy diets."),
    ("Leafy salad with avocado", "Mixed greens, cucumber, tomato and avocado with a lemon-olive-oil dressing.", "Light meal", _U % "1540420773420-3366772f4999", "plant", "Unsaturated fats and greens replace salty, fried sides."),
    ("Fresh vegetable platter", "Raw or lightly steamed seasonal vegetables with a hummus or yoghurt dip.", "Snack", _U % "1498837167922-ddd27525d352", "plant", "A crunchy swap for chips and fried snacks."),
    ("Wholesome grain bowl", "Brown rice or quinoa with beans, vegetables and herbs, little oil and salt.", "Meal bowl", _U % "1490645935967-10de6ba17061", "plant", "Whole grains and beans support steady energy and fibre intake."),
]
MOVE_BY_ACTIVITY = {
    "sedentary": ("Gentle movement starter", "Begin with short, comfortable movement breaks during the day. Ask your clinician what intensity is safe."),
    "light": ("Build a steady routine", "Try short walks or other low-impact movement, increasing gradually only if comfortable and medically cleared."),
    "moderate": ("Maintain a balanced routine", "Mix comfortable aerobic activity with mobility and strength work, if medically cleared."),
    "active": ("Recovery matters too", "Keep a sustainable routine with recovery days; avoid sudden increases in intensity."),
}


def photo_cards(profile):
    diet = (profile or {}).get("diet", "vegetarian")
    allowed = {"vegan": ("plant",), "vegetarian": ("plant", "all"), "eggetarian": ("plant", "all"), "non-vegetarian": ("plant", "all", "nonveg")}.get(diet, ("plant", "all"))
    foods = [{"title": t, "desc": d, "tag": g, "img": i, "why": y} for t, d, g, i, k, y in PHOTO_FOODS if k in allowed]
    move = MOVE_BY_ACTIVITY.get((profile or {}).get("activity", "light"), MOVE_BY_ACTIVITY["light"])
    exercises = [
        {"title": move[0], "desc": move[1], "tag": "Movement", "icon": "ti-walk", "img": _U % "1476480862126-209bfaa8edc8"},
        {"title": "Seated mobility", "desc": "Gentle shoulder rolls, ankle circles and comfortable range-of-motion movements.", "tag": "Low impact", "icon": "ti-yoga", "img": _U % "1518611012118-696072aa579a"},
        {"title": "Breathing & relaxation", "desc": "Try a calm breathing or relaxation practice. Stop if dizzy, breathless or uncomfortable.", "tag": "Recovery", "icon": "ti-wind", "img": _U % "1506126613408-6e9a6b6e5f2f"},
    ]
    return {"foods": foods, "exercises": exercises}


def build_plan(profile, payload, risk_level=None, shuffle=0):
    profile = profile or {}
    energy = daily_energy(profile, payload or {}) if payload else None
    kcal = energy["kcal"] if energy else None
    return {
        "bmi": bmi_info(profile.get("height"), profile.get("weight")),
        "energy": energy,
        "targets": nutrition_targets(kcal, profile, payload, risk_level),
        "meals": meal_plan(profile, kcal, shuffle),
        "exercise": exercise_plan(profile, payload or {}, risk_level),
        "warnings": food_warnings(profile, payload),
        "photos": photo_cards(profile),
        "eat_more": EAT_MORE, "limit": LIMIT, "swaps": SWAPS,
        "disclaimer": DISCLAIMER,
    }

Run `python train_model.py` to generate model artifacts in this directory. They are intentionally not pre-bundled.
